# Pulse Dialer

A native Android **phone / dialer app** that places and receives ordinary **SIM calls** through Android's own
telephony stack. No account, no server, no internet permission.

* Kotlin · Jetpack Compose (Material 3) · MVVM · Android Telecom (`InCallService`) · Room · DataStore
* `minSdk 26` (Android 8.0) · `targetSdk 35` · Gradle Kotlin DSL · no third-party libraries beyond AndroidX
* Package: `com.pulse.dialer` (rename the app in `strings.xml` / `namespace` if you prefer another name)

> **Status, honestly:** the source was written and statically checked (brace balance, resource references,
> imports) but **could not be compiled or run** in the environment that produced it (no Android SDK, no network,
> no phone). The first GitHub Actions run is the first real compile. Nothing in this project has been tested on a
> real device. See [Testing status](#testing-status).

---

## AI PROPOSED ENHANCEMENTS

Added on top of the brief because they make a *real* dialer more usable, and all work offline:

| Enhancement | Why |
|---|---|
| Proximity-sensor handling (screen off at the ear) | Without it a dialer is unusable: cheeks hang up calls. |
| "Return to call" bar on every screen | A call must never get lost behind other screens. |
| Redial last number (tap call on an empty keypad) | Standard dialer behaviour, one tap. |
| "Decline and block" on unknown incoming calls | Fastest way to deal with a nuisance caller. |
| Dual-SIM call buttons on the keypad | Choose the SIM in one tap instead of a dialog. |
| Honest recording pipeline (audio is measured; empty files are discarded) | Android often silences call audio; faking a recording would be worse than none. |
| Retention setting for recordings (7/30/90 days) + storage dashboard | Keeps storage under control without manual cleanup. |
| Favourites: reorder and custom photos (stored privately) | Brief asked for personalised favourites. |
| Swap / merge for call waiting and conference | Needed for real multi-call handling. |
| "Delete all Pulse data" | One-tap privacy reset. |

Needs hardware / OEM privileges / unsupported APIs, so **documented but not faked**: capturing the *other*
party's voice on most phones, caller-ID spam databases (needs internet), visual voicemail.

---

## Features

* **Default Phone app** via `RoleManager` (`ROLE_DIALER`); `InCallService` handles incoming, outgoing, waiting,
  hold, swap, merge, DTMF, mute, speaker, Bluetooth / wired routing, call timer, SIM label.
* **Keypad**: 0-9 * #, number formatting, tap/hold-to-delete, clear, `+` on long-press `0`, instant contact
  matching and **T9 search**, haptics, optional tones, dual-SIM call buttons.
* **Contacts** (Android's own database): list, search, details, add, edit, delete, favourites, photos, several numbers.
* **Call history** with All / Incoming / Outgoing / Missed / Rejected filters, call details, call back, save unknown
  number, delete entry, clear history, private **call notes**.
* **Dual SIM**: detects SIMs and carriers, per-call SIM choice, default-SIM preference ("Android's setting",
  "ask every time", or a fixed slot). Single-SIM and no-SIM devices are handled.
* **Unknown numbers**: clearly labelled, save in one tap, block list (local + Android system block list when allowed).
* **Call recording (optional, off by default)**: consent screen, separate auto-record switches for unknown and saved
  callers, visible notification + on-screen REC indicator, playback, delete, storage dashboard, retention.
* **Settings**: theme (system/light/dark), default-app status, SIM, recording, notifications, privacy, about.
* **Accessibility**: scalable text, content descriptions, 48dp+ touch targets, TalkBack actions on keypad keys.

## Known Android limitations

* Android does **not** guarantee third-party apps access to cellular call audio. Pulse tries the call-audio source
  first (works only on some devices/ROMs), then the microphone. With the microphone, the recording may contain only
  your side unless speakerphone is on. If Android returns only silence, the file is **discarded** and you are told.
* Recording may be blocked entirely on some Android versions / manufacturers / regions. No fake recordings are ever made.
* Recording is also subject to local law. Pulse never records secretly and shows indicators; informing the other
  party is the user's responsibility.
* The system call log is written by Android Telecom, not by Pulse. Clearing it needs the call-log permission.
* Blocking at ring time uses the local block list; the system block list is only writable when Pulse is the default app.
* Some manufacturers add extra background-start restrictions; the incoming-call screen then appears as a heads-up /
  full-screen notification instead of opening directly.
* `USE_FULL_SCREEN_INTENT` may need to be allowed in system settings on some Android 14+ builds.

## Build

### GitHub Actions (no Android Studio needed)

1. Create a repository and add `.github/workflows/build.yml` first (file provided separately and also inside the ZIP).
2. Upload **either** the extracted project files **or** the project ZIP to the repository root (a ZIP uploaded
   as a single file is extracted automatically by the workflow).
3. Open **Actions → Build Pulse Dialer APK → Artifacts → PulseDialer-debug-apk**.

### Android Studio

Open the folder (Ladybug or newer, JDK 17). Android Studio creates the Gradle wrapper on first sync.

### Command line

```
gradle assembleDebug        # or ./gradlew assembleDebug after running: gradle wrapper --gradle-version 8.9
```

The Gradle wrapper **jar** is a binary that could not be bundled (no network where this was produced);
`gradle/wrapper/gradle-wrapper.properties` is included and the workflow uses Gradle 8.9 directly.

Versions: AGP 8.7.3 · Kotlin 2.0.21 (+ Compose compiler plugin, KSP 2.0.21-1.0.28) · Compose BOM 2024.10.01 ·
Room 2.6.1 · compileSdk/targetSdk 35. They are deliberately a known-good set; bump `targetSdk` once you have tested.

## First run

1. Allow the permissions (explained on the first screen).
2. Tap **Set as default** and confirm Android's dialog. Without this Pulse can browse contacts and history but
   Android will not route calls to it.
3. Optional: Settings → Call recording.

## Project structure

```
app/src/main/java/com/pulse/dialer/
  DialerApp.kt, MainActivity.kt
  data/        Room DB, DataStore settings, repositories (contacts, call log, SIM, blocked, favourites, recordings)
  call/        PulseInCallService, CallManager, InCallActivity + InCallScreen, notifications, call actions
  recording/   RecordingController (honest pipeline), CallRecordingService (foreground service)
  viewmodel/   ContactsViewModel, HistoryViewModel, SettingsViewModel
  ui/          theme, shared components, navigation, screens
  util/        phone formatting, T9, time, permissions, default-dialer helper
```

## Privacy

No `INTERNET` permission, no analytics, no ads, no accounts. Contacts and call log are read from Android and never
copied elsewhere. Recordings, notes, block list and favourite extras live in app-private storage
(`allowBackup=false`) and can be deleted from Settings.

## Testing status

| Area | Status |
|---|---|
| Static checks (brace balance, resource references, import heuristics) | Done |
| Gradle / Kotlin compilation | **Not done** (first CI run is the first compile) |
| Default-dialer role, incoming/outgoing calls, dual SIM, Bluetooth routing | **Not tested on hardware** |
| Permission-denied paths | Implemented (empty states, no crashes expected), **not tested** |
| Call recording / fallback | Implemented, **not tested** on any device |
| Offline operation | By construction: no `INTERNET` permission in the manifest |

If the CI build reports a compile error, send me the log and I will fix it.
