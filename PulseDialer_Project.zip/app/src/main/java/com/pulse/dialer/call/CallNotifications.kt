package com.pulse.dialer.call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.pulse.dialer.MainActivity
import com.pulse.dialer.R
import com.pulse.dialer.util.PhoneUtils

object CallNotifications {
    const val CH_INCOMING = "incoming_calls"
    const val CH_ONGOING = "ongoing_call"
    const val CH_MISSED = "missed_calls"
    const val CH_RECORDING = "call_recording"

    const val ID_CALL = 1001
    const val ID_RECORDING = 1003
    const val ID_RECORDING_RESULT = 1004
    private const val ID_MISSED_BASE = 2000

    const val EXTRA_ACTION = "pulse_action"
    const val ACTION_ANSWER = "answer"

    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val incoming = NotificationChannel(CH_INCOMING, ctx.getString(R.string.channel_incoming), NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null) // Android Telecom plays the ringtone
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val ongoing = NotificationChannel(CH_ONGOING, ctx.getString(R.string.channel_ongoing), NotificationManager.IMPORTANCE_LOW).apply {
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val missed = NotificationChannel(CH_MISSED, ctx.getString(R.string.channel_missed), NotificationManager.IMPORTANCE_DEFAULT)
        val recording = NotificationChannel(CH_RECORDING, ctx.getString(R.string.channel_recording), NotificationManager.IMPORTANCE_LOW)
        nm.createNotificationChannels(listOf(incoming, ongoing, missed, recording))
    }

    private fun title(info: CallInfo): String =
        info.name ?: PhoneUtils.format(info.number).ifBlank { "Private number" }

    private fun inCallIntent(ctx: Context, requestCode: Int, answer: Boolean = false): PendingIntent {
        val i = Intent(ctx, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        if (answer) i.putExtra(EXTRA_ACTION, ACTION_ANSWER)
        return PendingIntent.getActivity(ctx, requestCode, i, FLAGS)
    }

    private fun broadcast(ctx: Context, requestCode: Int, action: String, number: String? = null): PendingIntent {
        val i = Intent(ctx, CallActionReceiver::class.java).setAction(action)
        if (number != null) i.putExtra(CallActionReceiver.EXTRA_NUMBER, number)
        return PendingIntent.getBroadcast(ctx, requestCode, i, FLAGS)
    }

    /** Heads-up + full-screen incoming call notification (Android decides which one fits the lock state). */
    fun showIncoming(ctx: Context, info: CallInfo) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val open = inCallIntent(ctx, 10)
        val n = NotificationCompat.Builder(ctx, CH_INCOMING)
            .setSmallIcon(R.drawable.ic_stat_call)
            .setContentTitle(title(info))
            .setContentText(
                buildString {
                    append(ctx.getString(R.string.incoming_call))
                    if (info.isUnknown) append(" · Unknown caller")
                    info.simLabel?.let { append(" · ").append(it) }
                }
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setFullScreenIntent(open, true)
            .setContentIntent(open)
            .addAction(R.drawable.ic_stat_call_end, ctx.getString(R.string.decline), broadcast(ctx, 12, CallActionReceiver.ACTION_DECLINE))
            .addAction(R.drawable.ic_stat_call, ctx.getString(R.string.answer), inCallIntent(ctx, 11, answer = true))
            .build()
        nm.notify(ID_CALL, n)
    }

    fun showOngoing(ctx: Context, info: CallInfo) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setSmallIcon(R.drawable.ic_stat_call)
            .setContentTitle(title(info))
            .setContentText(ctx.getString(R.string.ongoing_call))
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(inCallIntent(ctx, 13))
            .addAction(R.drawable.ic_stat_call_end, ctx.getString(R.string.hang_up), broadcast(ctx, 14, CallActionReceiver.ACTION_HANGUP))
        if (info.connectTimeMillis > 0 && info.state == CallUiState.Active) {
            b.setUsesChronometer(true).setShowWhen(true).setWhen(info.connectTimeMillis)
        }
        nm.notify(ID_CALL, b.build())
    }

    fun cancelCall(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(ID_CALL)
    }

    fun startInCallUi(ctx: Context) {
        val i = Intent(ctx, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            // Android may block background launches; the notification (full-screen intent) remains the fallback.
        }
    }

    private fun missedId(number: String) = ID_MISSED_BASE + (number.hashCode() and 0x7FFF)

    fun showMissed(ctx: Context, name: String?, number: String, sim: String?) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val who = name ?: PhoneUtils.format(number).ifBlank { "Private number" }
        val open = PendingIntent.getActivity(
            ctx, 20,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_ROUTE, "recents"),
            FLAGS
        )
        val b = NotificationCompat.Builder(ctx, CH_MISSED)
            .setSmallIcon(R.drawable.ic_stat_call_end)
            .setContentTitle(ctx.getString(R.string.missed_call))
            .setContentText(if (sim != null) "$who · $sim" else who)
            .setAutoCancel(true)
            .setContentIntent(open)
        if (number.isNotBlank()) {
            b.addAction(R.drawable.ic_stat_call, ctx.getString(R.string.call_back), broadcast(ctx, missedId(number), CallActionReceiver.ACTION_CALLBACK, number))
        }
        nm.notify(missedId(number), b.build())
    }

    fun cancelMissed(ctx: Context, number: String) {
        ctx.getSystemService(NotificationManager::class.java)?.cancel(missedId(number))
    }

    fun recordingNotification(ctx: Context, who: String): Notification =
        NotificationCompat.Builder(ctx, CH_RECORDING)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle("Recording call")
            .setContentText(who)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(R.drawable.ic_stat_call_end, ctx.getString(R.string.stop_recording), broadcast(ctx, 30, CallActionReceiver.ACTION_STOP_RECORDING))
            .build()

    fun recordingResult(ctx: Context, saved: Boolean, detail: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val n = NotificationCompat.Builder(ctx, CH_RECORDING)
            .setSmallIcon(R.drawable.ic_stat_rec)
            .setContentTitle(if (saved) "Call recording saved" else "Call was not recorded")
            .setContentText(detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detail))
            .setAutoCancel(true)
            .build()
        nm.notify(ID_RECORDING_RESULT, n)
    }
}
