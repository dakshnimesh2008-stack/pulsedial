package com.pulse.dialer.util

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.TelecomManager

object DefaultDialer {
    fun isDefault(context: Context): Boolean {
        val tm = context.getSystemService(TelecomManager::class.java) ?: return false
        return tm.defaultDialerPackage == context.packageName
    }

    /** Intent that asks Android to make this app the default Phone app, or null if unavailable/already held. */
    fun requestIntent(context: Context): Intent? {
        if (isDefault(context)) return null
        return if (Build.VERSION.SDK_INT >= 29) {
            val rm = context.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                rm.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            } else null
        } else {
            Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, context.packageName)
        }
    }
}
