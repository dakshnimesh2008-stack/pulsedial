package com.pulse.dialer.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pulse.dialer.R
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.Perms

@Composable
fun OnboardingScreen(
    perms: Perms,
    isDefault: Boolean,
    onRequestPerms: () -> Unit,
    onSetDefault: () -> Unit,
    onContinue: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_badge), contentDescription = "Pulse Dialer", modifier = Modifier.size(120.dp))
        Spacer(Modifier.height(16.dp))
        Text("Pulse Dialer", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Real SIM calls. Nothing online.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        StepCard(
            title = "1. Allow access",
            body = "Phone, contacts and call log, so Pulse can place calls and show your history. They are read from Android and never copied or uploaded.",
            done = perms.core,
            action = "Allow access",
            onAction = onRequestPerms
        )
        Spacer(Modifier.height(12.dp))
        StepCard(
            title = "2. Make Pulse your phone app",
            body = "Android sends calls to the default phone app. Without this step Pulse can browse contacts but can't handle calls.",
            done = isDefault,
            action = "Set as default",
            onAction = onSetDefault
        )
        Spacer(Modifier.height(24.dp))
        if (perms.core && isDefault) {
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Start using Pulse") }
        } else {
            TextButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Skip for now") }
        }
        Text(
            "No account. No server. No internet permission.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 12.dp)
        )
    }
}

@Composable
private fun StepCard(title: String, body: String, done: Boolean, action: String, onAction: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (done) Icon(Icons.Default.CheckCircle, contentDescription = "Done", tint = PulseColors.CallGreen)
            }
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!done) {
                Spacer(Modifier.height(12.dp))
                Button(onClick = onAction) { Text(action) }
            }
        }
    }
}
