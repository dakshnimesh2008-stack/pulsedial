package com.pulse.dialer.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import com.pulse.dialer.data.model.SimInfo
import com.pulse.dialer.util.Permissions

/** Reads SIM / carrier information. Works with 0, 1 or 2 SIMs and degrades quietly without permission. */
class SimRepository(private val context: Context) {

    fun hasPermission(): Boolean = Permissions.granted(context, Manifest.permission.READ_PHONE_STATE)

    @SuppressLint("MissingPermission")
    fun activeSims(): List<SimInfo> {
        if (!hasPermission()) return emptyList()
        return try {
            val sm = context.getSystemService(SubscriptionManager::class.java) ?: return emptyList()
            val tm = context.getSystemService(TelecomManager::class.java)
            val subs: List<SubscriptionInfo> = sm.activeSubscriptionInfoList ?: emptyList()
            val handles: List<PhoneAccountHandle> = (tm?.callCapablePhoneAccounts ?: emptyList()).filter { h ->
                tm?.getPhoneAccount(h)?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
            }
            subs.sortedBy { it.simSlotIndex }.mapIndexed { index, s ->
                SimInfo(
                    slotIndex = s.simSlotIndex,
                    subscriptionId = s.subscriptionId,
                    carrierName = (s.carrierName ?: s.displayName)?.toString().orEmpty(),
                    handle = findHandle(tm, s, handles, index, subs.size)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Best-effort matching of a SIM subscription to its Telecom account (the id format differs between devices). */
    private fun findHandle(
        tm: TelecomManager?, sub: SubscriptionInfo, handles: List<PhoneAccountHandle>, index: Int, simCount: Int
    ): PhoneAccountHandle? {
        handles.firstOrNull { it.id == sub.subscriptionId.toString() }?.let { return it }
        val icc = sub.iccId
        if (!icc.isNullOrBlank() && icc.length >= 10) {
            handles.firstOrNull { it.id.length >= 10 && (it.id.startsWith(icc.take(18)) || icc.startsWith(it.id.take(18))) }
                ?.let { return it }
        }
        val names = listOfNotNull(sub.displayName?.toString(), sub.carrierName?.toString())
        handles.firstOrNull { h ->
            val label = tm?.getPhoneAccount(h)?.label?.toString()
            label != null && names.any { it.equals(label, ignoreCase = true) }
        }?.let { return it }
        return if (handles.size == simCount) handles.getOrNull(index) else null
    }

    /** SIM chosen by Android's own "calls" preference, or null when it is set to "ask every time". */
    @SuppressLint("MissingPermission")
    fun defaultOutgoingHandle(): PhoneAccountHandle? = try {
        context.getSystemService(TelecomManager::class.java)
            ?.getDefaultOutgoingPhoneAccount(PhoneAccount.SCHEME_TELEPHONY)
    } catch (e: Exception) {
        null
    }

    fun labelForHandle(handle: PhoneAccountHandle?): String? {
        if (handle == null) return null
        val sims = activeSims()
        return sims.firstOrNull { it.handle == handle }?.fullLabel
            ?: sims.firstOrNull { it.handle?.id == handle.id || it.subscriptionId.toString() == handle.id }?.fullLabel
    }

    /** Maps a call-log PHONE_ACCOUNT_ID to a SIM label; only meaningful on dual-SIM phones. */
    fun labelForAccountId(sims: List<SimInfo>, accountId: String?): String? {
        if (accountId.isNullOrBlank() || sims.size < 2) return null
        return sims.firstOrNull { it.handle?.id == accountId || it.subscriptionId.toString() == accountId }?.label
    }
}
