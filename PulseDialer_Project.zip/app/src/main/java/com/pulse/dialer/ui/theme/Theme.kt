package com.pulse.dialer.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

object PulseColors {
    val CallGreen = Color(0xFF22C55E)
    val EndRed = Color(0xFFEF4444)
    val Amber = Color(0xFFF59E0B)
    val Cyan = Color(0xFF4DD8FF)
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD8FF),
    onPrimary = Color(0xFF00212B),
    primaryContainer = Color(0xFF0B3A52),
    onPrimaryContainer = Color(0xFFBDEBFF),
    secondary = Color(0xFF7C9CFF),
    onSecondary = Color(0xFF001A52),
    secondaryContainer = Color(0xFF1B2B5A),
    onSecondaryContainer = Color(0xFFDCE4FF),
    tertiary = Color(0xFF38D9A9),
    onTertiary = Color(0xFF00382A),
    background = Color(0xFF060B16),
    onBackground = Color(0xFFE6EEFB),
    surface = Color(0xFF0C1424),
    onSurface = Color(0xFFE6EEFB),
    surfaceVariant = Color(0xFF16213A),
    onSurfaceVariant = Color(0xFF9FB0CE),
    surfaceContainerLowest = Color(0xFF040812),
    surfaceContainerLow = Color(0xFF09101F),
    surfaceContainer = Color(0xFF0E172B),
    surfaceContainerHigh = Color(0xFF131E36),
    surfaceContainerHighest = Color(0xFF1A2742),
    outline = Color(0xFF3A4A6B),
    outlineVariant = Color(0xFF22304D),
    error = Color(0xFFFF6B7A),
    onError = Color(0xFF3B0008)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0072B5),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFCDEBFF),
    onPrimaryContainer = Color(0xFF001E31),
    secondary = Color(0xFF3F5BBF),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDDE3FF),
    onSecondaryContainer = Color(0xFF001257),
    tertiary = Color(0xFF00876A),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF0B1426),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B1426),
    surfaceVariant = Color(0xFFE3EAF6),
    onSurfaceVariant = Color(0xFF47556F),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF7F9FD),
    surfaceContainer = Color(0xFFEFF3FA),
    surfaceContainerHigh = Color(0xFFE8EEF8),
    surfaceContainerHighest = Color(0xFFE0E8F4),
    outline = Color(0xFF7A88A6),
    outlineVariant = Color(0xFFC9D3E6),
    error = Color(0xFFD92D3F),
    onError = Color(0xFFFFFFFF)
)

private val base = Typography()
private val PulseTypography = base.copy(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.Medium)
)

private val PulseShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun PulseTheme(
    themeMode: String = "system",
    forceDark: Boolean = false,
    content: @Composable () -> Unit
) {
    val dark = forceDark || when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = PulseTypography,
        shapes = PulseShapes,
        content = content
    )
}
