package com.pulse.dialer.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

/** Recordings live only in the app's private storage and are never uploaded anywhere. */
class RecordingRepository(private val context: Context, private val dao: RecordingDao) {
    fun observeAll(): Flow<List<RecordingEntity>> = dao.observeAll()
    fun observeTotalBytes(): Flow<Long> = dao.observeAll().map { list -> list.sumOf { it.sizeBytes } }

    suspend fun add(entity: RecordingEntity): Long = dao.insert(entity)

    suspend fun delete(entity: RecordingEntity) {
        File(entity.filePath).delete()
        dao.delete(entity.id)
    }

    suspend fun deleteAll() {
        dao.all().forEach { File(it.filePath).delete() }
        File(context.filesDir, "recordings").listFiles()?.forEach { it.delete() }
        dao.clear()
    }

    suspend fun purgeOlderThan(days: Int) {
        val cutoff = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000
        dao.olderThan(cutoff).forEach { delete(it) }
    }
}
