package com.pulse.dialer.recording

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import androidx.core.content.ContextCompat
import com.pulse.dialer.call.CallNotifications
import com.pulse.dialer.container
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.data.RecordingEntity
import com.pulse.dialer.util.Permissions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/**
 * Honest call recording.
 *
 * Android does not let ordinary apps capture the other party's voice from the cellular call. Pulse therefore
 * tries the call-audio source first (it only works on devices/ROMs that allow it) and then the microphone.
 * Audio is measured while recording: if Android hands back pure silence the file is discarded and the user is
 * told, instead of pretending a recording exists. Recordings made from the microphone are labelled as such.
 */
object RecordingController {
    enum class Phase { Idle, Recording, Unavailable }

    data class RecState(val phase: Phase = Phase.Idle, val message: String? = null, val startedAt: Long = 0L)
    data class Meta(val number: String, val name: String?, val incoming: Boolean, val unknown: Boolean, val simLabel: String?)

    private const val SILENCE_TIMEOUT_MS = 8_000

    private val sources = listOf(
        MediaRecorder.AudioSource.VOICE_CALL to "Call audio",
        MediaRecorder.AudioSource.MIC to "Microphone only"
    )

    private val _state = MutableStateFlow(RecState())
    val state: StateFlow<RecState> = _state.asStateFlow()

    private val main = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var meta: Meta? = null
    private var startedAt = 0L
    private var peak = 0
    private var sourceIndex = 0
    private var monitor: Job? = null
    private var appCtx: Context? = null
    private var startPending = false

    fun hasMic(ctx: Context) = Permissions.granted(ctx, Manifest.permission.RECORD_AUDIO)

    fun shouldAutoRecord(ctx: Context, s: AppSettings, incoming: Boolean, unknown: Boolean): Boolean {
        if (!s.recordingEnabled || !s.recordingConsent || !hasMic(ctx)) return false
        return if (unknown) incoming && s.autoRecordUnknown else s.autoRecordSaved
    }

    fun report(message: String) {
        _state.value = RecState(Phase.Unavailable, message)
    }

    fun resetIfIdle() {
        if (recorder == null && !startPending) _state.value = RecState()
    }

    fun currentLabel(): String {
        val m = meta ?: return "Call in progress"
        return m.name ?: m.number.ifBlank { "Private number" }
    }

    /** Asks the foreground service to start; the service calls [beginFromService] once it is in the foreground. */
    fun start(ctx: Context, m: Meta) {
        if (recorder != null || startPending) return
        appCtx = ctx.applicationContext
        meta = m
        startPending = true
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CallRecordingService::class.java))
        } catch (e: Exception) {
            startPending = false
            report("Android did not allow call recording to start right now, so this call was not recorded.")
        }
    }

    fun stop(ctx: Context) {
        ctx.stopService(Intent(ctx, CallRecordingService::class.java))
    }

    fun failToStart(message: String) {
        startPending = false
        report(message)
    }

    fun beginFromService(): Boolean {
        startPending = false
        val ctx = appCtx ?: return false
        return startRecorder(ctx, 0)
    }

    @Suppress("DEPRECATION")
    private fun newRecorder(ctx: Context): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()

    private fun startRecorder(ctx: Context, fromIndex: Int): Boolean {
        val dir = File(ctx.filesDir, "recordings").apply { mkdirs() }
        val tail = (meta?.number ?: "").filter { it.isDigit() }.takeLast(12).ifEmpty { "private" }
        val f = File(dir, "rec_${System.currentTimeMillis()}_$tail.m4a")
        for (i in fromIndex until sources.size) {
            val r = newRecorder(ctx)
            try {
                r.setAudioSource(sources[i].first)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(64_000)
                r.setAudioSamplingRate(16_000)
                r.setOutputFile(f.absolutePath)
                r.prepare()
                r.start()
                recorder = r
                file = f
                sourceIndex = i
                startedAt = System.currentTimeMillis()
                peak = 0
                _state.value = RecState(Phase.Recording, null, startedAt)
                startMonitor()
                return true
            } catch (e: Exception) {
                runCatching { r.reset() }
                runCatching { r.release() }
                f.delete()
            }
        }
        _state.value = RecState(
            Phase.Unavailable,
            "Android did not give Pulse access to call audio on this device, so this call was not recorded."
        )
        return false
    }

    private fun startMonitor() {
        monitor?.cancel()
        monitor = main.launch {
            var elapsed = 0
            while (isActive) {
                delay(500)
                elapsed += 500
                val amp = try { recorder?.maxAmplitude ?: 0 } catch (e: Exception) { 0 }
                if (amp > peak) peak = amp
                if (peak == 0 && elapsed >= SILENCE_TIMEOUT_MS) {
                    onSilence()
                    return@launch
                }
            }
        }
    }

    /** Pure silence means Android is blocking the source: try the next one, otherwise give up honestly. */
    private fun onSilence() {
        val ctx = appCtx ?: return
        val idx = sourceIndex
        discardCurrent()
        if (idx + 1 < sources.size && startRecorder(ctx, idx + 1)) return
        report("Android returned only silence for this call (call audio is blocked on this device), so nothing was saved.")
        CallNotifications.recordingResult(ctx, false, "Android blocked access to call audio on this device. Nothing was saved.")
        stop(ctx)
    }

    private fun discardCurrent() {
        monitor?.cancel()
        recorder?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        recorder = null
        file?.delete()
        file = null
    }

    /** Called when the service stops (call ended or user pressed stop). Saves only recordings that contain audio. */
    fun finish() {
        val r = recorder
        if (r == null) {
            startPending = false
            return
        }
        monitor?.cancel()
        val f = file
        val m = meta
        val ctx = appCtx
        var stopped = true
        try { r.stop() } catch (e: Exception) { stopped = false }
        runCatching { r.release() }
        recorder = null
        file = null
        val duration = System.currentTimeMillis() - startedAt
        val source = sources[sourceIndex].second
        if (f != null && m != null && ctx != null && stopped && peak > 0 && f.exists() && f.length() > 2_048) {
            _state.value = RecState()
            val size = f.length()
            io.launch {
                runCatching {
                    ctx.container.recordings.add(
                        RecordingEntity(
                            filePath = f.absolutePath,
                            number = m.number,
                            contactName = m.name,
                            isIncoming = m.incoming,
                            isUnknownCaller = m.unknown,
                            startedAt = startedAt,
                            durationMs = duration,
                            sizeBytes = size,
                            simLabel = m.simLabel,
                            audioSource = source
                        )
                    )
                }
                val detail = if (source == "Microphone only") {
                    "Saved from the microphone only: it may contain just your side unless speakerphone was on."
                } else "Saved in Settings › Recordings."
                CallNotifications.recordingResult(ctx, true, detail)
            }
        } else {
            f?.delete()
            report("No audio was captured, so nothing was saved.")
            if (ctx != null) CallNotifications.recordingResult(ctx, false, "No audio was captured, so nothing was saved.")
        }
    }
}
