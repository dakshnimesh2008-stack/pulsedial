package com.pulse.dialer.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.ui.components.DialHost
import com.pulse.dialer.ui.components.rememberCorePermissionRequester
import com.pulse.dialer.ui.components.rememberDefaultDialerRequester
import com.pulse.dialer.ui.components.rememberIsDefaultDialer
import com.pulse.dialer.ui.components.rememberPerms
import com.pulse.dialer.ui.screens.OnboardingScreen
import com.pulse.dialer.viewmodel.SettingsViewModel

/** First run shows the permission / default-app onboarding, afterwards the main navigation. */
@Composable
fun PulseRoot(
    settings: AppSettings,
    dialNumber: String?,
    onDialConsumed: () -> Unit,
    routeRequest: String?,
    onRouteConsumed: () -> Unit
) {
    val settingsVm: SettingsViewModel = viewModel()
    val perms = rememberPerms()
    val isDefault = rememberIsDefaultDialer()
    val requestPerms = rememberCorePermissionRequester()
    val requestDefault = rememberDefaultDialerRequester()

    if (!settings.onboardingDone) {
        OnboardingScreen(
            perms = perms,
            isDefault = isDefault,
            onRequestPerms = requestPerms,
            onSetDefault = requestDefault,
            onContinue = { settingsVm.setOnboardingDone() }
        )
    } else {
        DialHost {
            PulseNavHost(settings, dialNumber, onDialConsumed, routeRequest, onRouteConsumed)
        }
    }
}
