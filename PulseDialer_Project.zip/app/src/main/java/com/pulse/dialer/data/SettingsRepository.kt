package com.pulse.dialer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.pulseStore: DataStore<Preferences> by preferencesDataStore(name = "pulse_settings")

data class AppSettings(
    val theme: String = "system",            // system | light | dark
    val haptics: Boolean = true,
    val dialTones: Boolean = false,
    val defaultSim: String = "system",       // system | ask | slot:<n>
    val recordingEnabled: Boolean = false,
    val autoRecordUnknown: Boolean = false,
    val autoRecordSaved: Boolean = false,
    val recordingConsent: Boolean = false,
    val retentionDays: Int = 0,              // 0 = keep forever
    val missedNotifications: Boolean = true,
    val rejectBlocked: Boolean = true,
    val onboardingDone: Boolean = false
)

class SettingsRepository(private val context: Context) {
    private object K {
        val THEME = stringPreferencesKey("theme")
        val HAPTICS = booleanPreferencesKey("haptics")
        val DIAL_TONES = booleanPreferencesKey("dial_tones")
        val DEFAULT_SIM = stringPreferencesKey("default_sim")
        val REC_ENABLED = booleanPreferencesKey("rec_enabled")
        val REC_UNKNOWN = booleanPreferencesKey("rec_unknown")
        val REC_SAVED = booleanPreferencesKey("rec_saved")
        val REC_CONSENT = booleanPreferencesKey("rec_consent")
        val RETENTION = intPreferencesKey("retention_days")
        val MISSED = booleanPreferencesKey("missed_notifications")
        val REJECT_BLOCKED = booleanPreferencesKey("reject_blocked")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<AppSettings> = context.pulseStore.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            AppSettings(
                theme = p[K.THEME] ?: "system",
                haptics = p[K.HAPTICS] ?: true,
                dialTones = p[K.DIAL_TONES] ?: false,
                defaultSim = p[K.DEFAULT_SIM] ?: "system",
                recordingEnabled = p[K.REC_ENABLED] ?: false,
                autoRecordUnknown = p[K.REC_UNKNOWN] ?: false,
                autoRecordSaved = p[K.REC_SAVED] ?: false,
                recordingConsent = p[K.REC_CONSENT] ?: false,
                retentionDays = p[K.RETENTION] ?: 0,
                missedNotifications = p[K.MISSED] ?: true,
                rejectBlocked = p[K.REJECT_BLOCKED] ?: true,
                onboardingDone = p[K.ONBOARDING] ?: false
            )
        }

    suspend fun current(): AppSettings = settings.first()

    suspend fun setTheme(v: String) = edit { it[K.THEME] = v }
    suspend fun setHaptics(v: Boolean) = edit { it[K.HAPTICS] = v }
    suspend fun setDialTones(v: Boolean) = edit { it[K.DIAL_TONES] = v }
    suspend fun setDefaultSim(v: String) = edit { it[K.DEFAULT_SIM] = v }
    suspend fun setAutoRecordUnknown(v: Boolean) = edit { it[K.REC_UNKNOWN] = v }
    suspend fun setAutoRecordSaved(v: Boolean) = edit { it[K.REC_SAVED] = v }
    suspend fun setRetentionDays(v: Int) = edit { it[K.RETENTION] = v }
    suspend fun setMissedNotifications(v: Boolean) = edit { it[K.MISSED] = v }
    suspend fun setRejectBlocked(v: Boolean) = edit { it[K.REJECT_BLOCKED] = v }
    suspend fun setOnboardingDone(v: Boolean) = edit { it[K.ONBOARDING] = v }

    suspend fun enableRecording() = edit {
        it[K.REC_ENABLED] = true
        it[K.REC_CONSENT] = true
    }

    suspend fun disableRecording() = edit { it[K.REC_ENABLED] = false }

    suspend fun resetAll() {
        context.pulseStore.edit { it.clear() }
    }

    private suspend fun edit(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.pulseStore.edit { block(it) }
    }
}
