package com.pulse.dialer.recording

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.pulse.dialer.call.CallNotifications

/**
 * Foreground service that keeps the recorder legal and visible: Android requires a foreground service with a
 * visible notification for microphone use, and the notification doubles as the user's recording indicator.
 */
class CallRecordingService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = CallNotifications.recordingNotification(this, RecordingController.currentLabel())
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                ServiceCompat.startForeground(
                    this, CallNotifications.ID_RECORDING, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else {
                startForeground(CallNotifications.ID_RECORDING, notification)
            }
        } catch (e: Exception) {
            RecordingController.failToStart("Android did not allow the recording service to start, so this call was not recorded.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!RecordingController.beginFromService()) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        RecordingController.finish()
        super.onDestroy()
    }
}
