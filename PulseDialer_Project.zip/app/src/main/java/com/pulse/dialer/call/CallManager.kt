package com.pulse.dialer.call

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.DisconnectCause
import android.telecom.InCallService
import android.telecom.VideoProfile
import androidx.core.app.NotificationManagerCompat
import com.pulse.dialer.container
import com.pulse.dialer.data.model.ContactMatch
import com.pulse.dialer.recording.RecordingController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Single source of truth for live calls. [PulseInCallService] feeds it with android.telecom.Call objects;
 * the UI observes [calls], [audio] and [lastEnded]. Nothing here simulates a call: every action is
 * forwarded to Android Telecom.
 */
object CallManager {
    private class Tracked(val call: Call, val incoming: Boolean) {
        val key: Int = System.identityHashCode(call)
        var match: ContactMatch? = null
        var simLabel: String? = null
        var callback: Call.Callback? = null
        var wasActive = false
        var hidden = false
        var connectedAt = 0L
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val tracked = LinkedHashMap<Call, Tracked>()
    private var service: InCallService? = null
    private var appContext: Context? = null
    private var proximityLock: PowerManager.WakeLock? = null
    private var lastNotifSig: String? = null
    private var recordingKey: Int? = null

    private val _calls = MutableStateFlow<List<CallInfo>>(emptyList())
    val calls: StateFlow<List<CallInfo>> = _calls.asStateFlow()

    private val _audio = MutableStateFlow(AudioInfo())
    val audio: StateFlow<AudioInfo> = _audio.asStateFlow()

    private val _lastEnded = MutableStateFlow<EndedInfo?>(null)
    val lastEnded: StateFlow<EndedInfo?> = _lastEnded.asStateFlow()

    val canAddCall: Boolean get() = service?.canAddCall() ?: false

    // ---- Service lifecycle -------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun attach(s: InCallService) {
        service = s
        appContext = s.applicationContext
        s.callAudioState?.let { _audio.value = audioFrom(it) }
    }

    fun detach() {
        service = null
        releaseProximity()
    }

    fun onAudioState(state: CallAudioState?) {
        if (state != null) _audio.value = audioFrom(state)
        updateProximity()
    }

    private fun audioFrom(s: CallAudioState) = AudioInfo(s.route, s.supportedRouteMask, s.isMuted)

    // ---- Call events -------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    fun onCallAdded(call: Call) {
        val t = Tracked(call, call.state == Call.STATE_RINGING)
        if (tracked.isEmpty()) {
            _lastEnded.value = null
            RecordingController.resetIfIdle()
        }
        tracked[call] = t
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) = handleState(t, state)
            override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
        }
        t.callback = cb
        call.registerCallback(cb)
        publish()
        scope.launch { prepare(t) }
    }

    /** Looks up the caller, applies the block list, then shows the right UI / notification. */
    @Suppress("DEPRECATION")
    private suspend fun prepare(t: Tracked) {
        val ctx = appContext ?: return
        val c = ctx.container
        val number = numberOf(t.call)
        val handle = t.call.details?.accountHandle
        t.match = withContext(Dispatchers.IO) { c.contacts.lookup(number) }
        t.simLabel = withContext(Dispatchers.IO) { c.sims.labelForHandle(handle) }
        if (!tracked.containsKey(t.call)) return

        if (t.incoming) {
            val settings = c.settings.current()
            val blocked = settings.rejectBlocked && withContext(Dispatchers.IO) { c.blocked.isBlocked(number) }
            if (blocked && t.call.state == Call.STATE_RINGING) {
                t.hidden = true
                t.call.reject(false, null)
                publish()
                return
            }
        }
        publish()
        val info = _calls.value.firstOrNull { it.key == t.key } ?: return
        if (t.incoming && t.call.state == Call.STATE_RINGING) {
            if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                CallNotifications.showIncoming(ctx, info)
            } else {
                CallNotifications.startInCallUi(ctx)
            }
        } else if (!t.incoming) {
            CallNotifications.startInCallUi(ctx)
        }
    }

    @Suppress("DEPRECATION")
    private fun handleState(t: Tracked, state: Int) {
        if (state == Call.STATE_ACTIVE && !t.wasActive) {
            t.wasActive = true
            t.connectedAt = connectTime(t.call)
            onBecameActive(t)
        }
        publish()
    }

    @Suppress("DEPRECATION")
    fun onCallRemoved(call: Call) {
        val t = tracked.remove(call) ?: return
        t.callback?.let { call.unregisterCallback(it) }
        val code = call.details?.disconnectCause?.code ?: DisconnectCause.UNKNOWN
        val number = numberOf(call)
        val missed = t.incoming && !t.wasActive && !t.hidden && code == DisconnectCause.MISSED
        val seconds = if (t.wasActive && t.connectedAt > 0) (System.currentTimeMillis() - t.connectedAt) / 1000 else 0L
        if (!t.hidden) {
            _lastEnded.value = EndedInfo(t.match?.name, number, t.match?.photoUri, seconds, missed)
        }
        val ctx = appContext
        if (ctx != null && missed) {
            val name = t.match?.name
            val sim = t.simLabel
            scope.launch {
                if (ctx.container.settings.current().missedNotifications) {
                    CallNotifications.showMissed(ctx, name, number, sim)
                }
            }
        }
        if (ctx != null && (recordingKey == t.key || tracked.isEmpty())) {
            RecordingController.stop(ctx)
            recordingKey = null
        }
        publish()
    }

    // ---- Publishing --------------------------------------------------------------------------

    private fun order(s: CallUiState) = when (s) {
        CallUiState.Ringing -> 0
        CallUiState.Active, CallUiState.Dialing, CallUiState.Connecting -> 1
        CallUiState.Holding -> 2
        CallUiState.Disconnecting -> 3
    }

    private fun publish() {
        val infos = tracked.values
            .filter { !it.hidden && it.call.parent == null }
            .map { toInfo(it) }
            .sortedBy { order(it.state) }
        _calls.value = infos
        updateProximity()

        val ctx = appContext ?: return
        val primary = infos.firstOrNull()
        if (primary == null) {
            CallNotifications.cancelCall(ctx)
            lastNotifSig = null
            return
        }
        if (primary.state == CallUiState.Ringing) {
            lastNotifSig = "ring:${primary.key}"
            return
        }
        val sig = "${primary.key}|${primary.state}|${primary.name}|${primary.connectTimeMillis}|${infos.size}"
        if (sig != lastNotifSig) {
            lastNotifSig = sig
            CallNotifications.showOngoing(ctx, primary)
        }
    }

    @Suppress("DEPRECATION")
    private fun toInfo(t: Tracked): CallInfo {
        val call = t.call
        val d = call.details
        val caps = d.callCapabilities
        val state = when (call.state) {
            Call.STATE_RINGING -> CallUiState.Ringing
            Call.STATE_DIALING -> CallUiState.Dialing
            Call.STATE_CONNECTING, Call.STATE_NEW, Call.STATE_SELECT_PHONE_ACCOUNT -> CallUiState.Connecting
            Call.STATE_ACTIVE -> CallUiState.Active
            Call.STATE_HOLDING -> CallUiState.Holding
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> CallUiState.Disconnecting
            else -> CallUiState.Active
        }
        val number = numberOf(call)
        val isConf = d.hasProperty(Call.Details.PROPERTY_CONFERENCE)
        return CallInfo(
            key = t.key,
            number = number,
            name = t.match?.name ?: d.callerDisplayName?.takeIf { it.isNotBlank() },
            photoUri = t.match?.photoUri,
            isUnknown = t.match == null && !isConf,
            isIncoming = t.incoming,
            state = state,
            connectTimeMillis = if (t.connectedAt > 0) t.connectedAt else connectTime(call),
            simLabel = t.simLabel,
            isConference = isConf,
            conferenceSize = if (isConf) call.children.size else 0,
            canHold = (caps and Call.Details.CAPABILITY_HOLD) != 0 || (caps and Call.Details.CAPABILITY_SUPPORT_HOLD) != 0,
            canMerge = call.conferenceableCalls.isNotEmpty() || (caps and Call.Details.CAPABILITY_MERGE_CONFERENCE) != 0
        )
    }

    private fun numberOf(call: Call): String = call.details?.handle?.schemeSpecificPart.orEmpty()

    private fun connectTime(call: Call): Long {
        val t = call.details?.connectTimeMillis ?: 0L
        return if (t > 0) t else 0L
    }

    // ---- Controls ----------------------------------------------------------------------------

    private fun sorted(): List<Tracked> =
        tracked.values.filter { !it.hidden && it.call.parent == null }.sortedBy { order(stateOf(it.call)) }

    @Suppress("DEPRECATION")
    private fun stateOf(call: Call): CallUiState = when (call.state) {
        Call.STATE_RINGING -> CallUiState.Ringing
        Call.STATE_HOLDING -> CallUiState.Holding
        Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> CallUiState.Disconnecting
        else -> CallUiState.Active
    }

    private fun byKey(key: Int?): Tracked? = if (key == null) sorted().firstOrNull() else tracked.values.firstOrNull { it.key == key }

    @Suppress("DEPRECATION")
    fun answerRinging() {
        sorted().firstOrNull { it.call.state == Call.STATE_RINGING }?.call?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }

    @Suppress("DEPRECATION")
    fun rejectRinging() {
        sorted().firstOrNull { it.call.state == Call.STATE_RINGING }?.call?.reject(false, null)
    }

    /** Declines the ringing call and adds the number to the block list. */
    fun rejectAndBlock() {
        val ctx = appContext
        val t = sorted().firstOrNull() ?: return
        val number = numberOf(t.call)
        rejectRinging()
        if (ctx != null && number.isNotBlank()) {
            scope.launch { withContext(Dispatchers.IO) { ctx.container.blocked.block(number) } }
        }
    }

    @Suppress("DEPRECATION")
    fun hangup(key: Int? = null) {
        val t = byKey(key) ?: return
        if (t.call.state == Call.STATE_RINGING) t.call.reject(false, null) else t.call.disconnect()
    }

    fun hangupPrimary() = hangup(null)

    @Suppress("DEPRECATION")
    fun toggleHold(key: Int) {
        val t = byKey(key) ?: return
        if (t.call.state == Call.STATE_HOLDING) t.call.unhold() else t.call.hold()
    }

    /** Brings the held call back; Android puts the active one on hold automatically. */
    @Suppress("DEPRECATION")
    fun swap() {
        sorted().firstOrNull { it.call.state == Call.STATE_HOLDING }?.call?.unhold()
    }

    @Suppress("DEPRECATION")
    fun merge() {
        val active = sorted().firstOrNull { it.call.state == Call.STATE_ACTIVE } ?: return
        val other = active.call.conferenceableCalls.firstOrNull()
        if (other != null) active.call.conference(other) else active.call.mergeConference()
    }

    fun toggleMute() {
        service?.setMuted(!_audio.value.muted)
    }

    @Suppress("DEPRECATION")
    fun setRoute(route: Int) {
        service?.setAudioRoute(route)
    }

    fun dtmf(c: Char) {
        val call = sorted().firstOrNull()?.call ?: return
        call.playDtmfTone(c)
        handler.postDelayed({ call.stopDtmfTone() }, 150)
    }

    fun openCallScreen(ctx: Context) = CallNotifications.startInCallUi(ctx)

    // ---- Recording ---------------------------------------------------------------------------

    private fun onBecameActive(t: Tracked) {
        val ctx = appContext ?: return
        scope.launch {
            val s = ctx.container.settings.current()
            val unknown = t.match == null
            if (RecordingController.shouldAutoRecord(ctx, s, t.incoming, unknown)) startRecording(t)
        }
    }

    private fun startRecording(t: Tracked) {
        val ctx = appContext ?: return
        recordingKey = t.key
        RecordingController.start(
            ctx,
            RecordingController.Meta(
                number = numberOf(t.call),
                name = t.match?.name,
                incoming = t.incoming,
                unknown = t.match == null,
                simLabel = t.simLabel
            )
        )
    }

    fun toggleRecording() {
        val ctx = appContext ?: return
        if (RecordingController.state.value.phase == RecordingController.Phase.Recording) {
            RecordingController.stop(ctx)
            return
        }
        val t = sorted().firstOrNull() ?: return
        scope.launch {
            val s = ctx.container.settings.current()
            if (s.recordingEnabled && s.recordingConsent && RecordingController.hasMic(ctx)) {
                startRecording(t)
            } else {
                RecordingController.report("Turn on call recording and allow microphone access in Settings first.")
            }
        }
    }

    // ---- Proximity sensor (screen off at the ear) ----------------------------------------------

    @Suppress("DEPRECATION")
    private fun updateProximity() {
        val ctx = appContext ?: return
        val live = tracked.values.any {
            !it.hidden && (it.call.state == Call.STATE_ACTIVE || it.call.state == Call.STATE_DIALING)
        }
        val need = live && _audio.value.route == CallAudioState.ROUTE_EARPIECE
        val pm = ctx.getSystemService(PowerManager::class.java) ?: return
        if (need) {
            if (proximityLock == null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                proximityLock = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "pulse:proximity")
            }
            proximityLock?.let { if (!it.isHeld) it.acquire() }
        } else {
            releaseProximity()
        }
    }

    private fun releaseProximity() {
        proximityLock?.let { if (it.isHeld) it.release() }
    }
}
