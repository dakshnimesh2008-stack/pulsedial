package com.pulse.dialer.data

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import com.pulse.dialer.data.model.Contact
import com.pulse.dialer.data.model.ContactMatch
import com.pulse.dialer.data.model.PhoneEntry
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.Permissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/** Thin layer over Android's own contacts database. Never copies contacts into app storage. */
class ContactsRepository(private val context: Context) {
    private val resolver get() = context.contentResolver

    private companion object {
        const val COL_PHOTO = "photo_thumb_uri"
        const val COL_STARRED = "starred"
    }

    fun hasRead() = Permissions.granted(context, Manifest.permission.READ_CONTACTS)
    fun hasWrite() = Permissions.granted(context, Manifest.permission.WRITE_CONTACTS)

    fun observe(): Flow<List<Contact>> = callbackFlow<Unit> {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        if (hasRead()) resolver.registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, observer)
        trySend(Unit)
        awaitClose { resolver.unregisterContentObserver(observer) }
    }.conflate().map { load() }.flowOn(Dispatchers.IO)

    private class Builder(val id: Long, val lookup: String, val name: String, val photo: String?, val starred: Boolean) {
        val phones = mutableListOf<PhoneEntry>()
        val keys = HashSet<String>()
    }

    private fun load(): List<Contact> {
        if (!hasRead()) return emptyList()
        val projection = arrayOf(
            Phone._ID, Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME,
            COL_PHOTO, COL_STARRED, Phone.NUMBER, Phone.TYPE, Phone.LABEL
        )
        val map = LinkedHashMap<Long, Builder>()
        try {
            resolver.query(Phone.CONTENT_URI, projection, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val contactId = c.getLong(1)
                    val number = c.getString(6)?.takeIf { it.isNotBlank() } ?: continue
                    val b = map.getOrPut(contactId) {
                        Builder(
                            id = contactId,
                            lookup = c.getString(2) ?: "",
                            name = c.getString(3) ?: "",
                            photo = c.getString(4),
                            starred = c.getInt(5) == 1
                        )
                    }
                    val key = PhoneUtils.matchKey(number)
                    if (b.keys.add(key.ifEmpty { number })) {
                        b.phones.add(PhoneEntry(c.getLong(0), number, c.getInt(7), c.getString(8)))
                    }
                }
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return map.values
            .map { b ->
                Contact(
                    id = b.id,
                    lookupKey = b.lookup,
                    name = b.name.ifBlank { b.phones.firstOrNull()?.number ?: "" },
                    photoUri = b.photo,
                    starred = b.starred,
                    phones = b.phones
                )
            }
            .sortedWith { a, b -> a.name.compareTo(b.name, ignoreCase = true) }
    }

    /** Looks a number up through Android's PhoneLookup (handles country codes and formatting). */
    suspend fun lookup(number: String): ContactMatch? = withContext(Dispatchers.IO) {
        if (number.isBlank() || !hasRead()) return@withContext null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            resolver.query(
                uri,
                arrayOf(
                    ContactsContract.PhoneLookup.DISPLAY_NAME,
                    ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI,
                    ContactsContract.PhoneLookup.LOOKUP_KEY
                ),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) ContactMatch(c.getString(0) ?: number, c.getString(1), c.getString(2)) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun create(name: String, phones: List<PhoneEntry>): Boolean = try {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build()
        )
        if (name.isNotBlank()) {
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                    .withValue(StructuredName.DISPLAY_NAME, name)
                    .build()
            )
        }
        phones.forEach { p ->
            ops.add(
                ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                    .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                    .withValue(Phone.NUMBER, p.number)
                    .withValue(Phone.TYPE, p.type)
                    .build()
            )
        }
        resolver.applyBatch(ContactsContract.AUTHORITY, ops)
        true
    } catch (e: Exception) {
        false
    }

    private fun firstRawContactId(contactId: Long): Long? =
        resolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID),
            "${ContactsContract.RawContacts.CONTACT_ID}=?",
            arrayOf(contactId.toString()),
            null
        )?.use { c -> if (c.moveToFirst()) c.getLong(0) else null }

    fun update(existing: Contact, newName: String, newPhones: List<PhoneEntry>): Boolean = try {
        val rawId = firstRawContactId(existing.id) ?: return false
        if (newName != existing.name) {
            val values = ContentValues().apply { put(StructuredName.DISPLAY_NAME, newName) }
            val updated = resolver.update(
                ContactsContract.Data.CONTENT_URI, values,
                "${ContactsContract.Data.RAW_CONTACT_ID}=? AND ${ContactsContract.Data.MIMETYPE}=?",
                arrayOf(rawId.toString(), StructuredName.CONTENT_ITEM_TYPE)
            )
            if (updated == 0) {
                values.put(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                values.put(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
                resolver.insert(ContactsContract.Data.CONTENT_URI, values)
            }
        }
        val ops = ArrayList<ContentProviderOperation>()
        existing.phones.filter { old -> newPhones.none { it.dataId == old.dataId } }.forEach { old ->
            ops.add(ContentProviderOperation.newDelete(ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, old.dataId)).build())
        }
        newPhones.forEach { p ->
            if (p.dataId == 0L) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValue(ContactsContract.Data.RAW_CONTACT_ID, rawId)
                        .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
                        .withValue(Phone.NUMBER, p.number)
                        .withValue(Phone.TYPE, p.type)
                        .build()
                )
            } else {
                val old = existing.phones.firstOrNull { it.dataId == p.dataId }
                if (old != null && (old.number != p.number || old.type != p.type)) {
                    ops.add(
                        ContentProviderOperation.newUpdate(ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, p.dataId))
                            .withValue(Phone.NUMBER, p.number)
                            .withValue(Phone.TYPE, p.type)
                            .build()
                    )
                }
            }
        }
        if (ops.isNotEmpty()) resolver.applyBatch(ContactsContract.AUTHORITY, ops)
        true
    } catch (e: Exception) {
        false
    }

    fun delete(lookupKey: String): Boolean = try {
        resolver.delete(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey), null, null) > 0
    } catch (e: Exception) {
        false
    }

    fun setStarred(contactId: Long, starred: Boolean): Boolean = try {
        val values = ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (starred) 1 else 0) }
        resolver.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactId), values, null, null) > 0
    } catch (e: Exception) {
        false
    }
}
