package com.pulse.dialer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.TabScaffold
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.Perms
import com.pulse.dialer.util.T9
import com.pulse.dialer.viewmodel.ContactsViewModel

@Composable
fun ContactsScreen(
    vm: ContactsViewModel,
    perms: Perms,
    onRequestPerms: () -> Unit,
    onOpenContact: (Long) -> Unit,
    onAdd: () -> Unit,
    onSettings: () -> Unit
) {
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }

    TabScaffold(title = "Contacts", onSettings = onSettings) {
        if (!perms.contacts) {
            EmptyState(
                Icons.Default.Contacts, "Contacts access is off",
                "Pulse reads the contacts already on your phone. Nothing is copied or uploaded.",
                "Allow access", onRequestPerms
            )
            return@TabScaffold
        }
        val filtered = remember(query, contacts) {
            val q = query.trim()
            if (q.isEmpty()) contacts else {
                val qd = PhoneUtils.digits(q)
                contacts.filter { ct ->
                    ct.name.contains(q, ignoreCase = true) ||
                        (qd.length >= 2 && ct.phones.any { PhoneUtils.digits(it.number).contains(qd) }) ||
                        (q.all { it.isDigit() } && T9.matches(ct.name, q))
                }
            }
        }
        val grouped = remember(filtered) {
            filtered.groupBy { ct -> ct.name.firstOrNull { it.isLetter() }?.uppercaseChar()?.toString() ?: "#" }
                .toSortedMap(compareBy<String> { if (it == "#") "\uFFFF" else it })
        }

        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search name or number") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Clear search") }
                        }
                    },
                    shape = RoundedCornerShape(28.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        disabledIndicatorColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
                when {
                    loading && contacts.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    filtered.isEmpty() -> EmptyState(
                        Icons.Default.Contacts,
                        if (query.isBlank()) "No contacts yet" else "No matches",
                        if (query.isBlank()) "Tap + to add your first contact." else "Try a different name or number."
                    )
                    else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 96.dp)) {
                        grouped.forEach { (letter, list) ->
                            item(key = "h_$letter") {
                                Text(
                                    letter,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                                )
                            }
                            items(list, key = { it.id }) { ct ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { onOpenContact(ct.id) }
                                        .padding(horizontal = 20.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ContactAvatar(ct.name, ct.photoUri, 46.dp)
                                    Spacer(Modifier.size(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(ct.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        val extra = if (ct.phones.size > 1) "  +${ct.phones.size - 1}" else ""
                                        Text(
                                            PhoneUtils.format(ct.primaryNumber.orEmpty()) + extra,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            FloatingActionButton(
                onClick = onAdd,
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
                containerColor = MaterialTheme.colorScheme.primary
            ) { Icon(Icons.Default.Add, contentDescription = "Add contact") }
        }
    }
}
