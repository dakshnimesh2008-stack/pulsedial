package com.pulse.dialer.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Favourite ordering and optional personalised photos. The favourite flag itself lives in Android contacts. */
class FavouritesRepository(private val context: Context, private val dao: FavouriteDao) {
    private val photoDir get() = File(context.filesDir, "favourite_photos").apply { mkdirs() }

    fun observeAll(): Flow<List<FavouriteMetaEntity>> = dao.observeAll()

    suspend fun ensureMeta(lookupKey: String) {
        if (lookupKey.isBlank() || dao.get(lookupKey) != null) return
        dao.put(FavouriteMetaEntity(lookupKey, dao.maxIndex() + 1, null))
    }

    suspend fun removeMeta(lookupKey: String) {
        dao.get(lookupKey)?.customPhotoPath?.let { File(it).delete() }
        dao.delete(lookupKey)
    }

    suspend fun saveOrder(lookupKeys: List<String>) {
        val existing = dao.all().associateBy { it.lookupKey }
        lookupKeys.forEachIndexed { index, key ->
            dao.put(FavouriteMetaEntity(key, index, existing[key]?.customPhotoPath))
        }
    }

    suspend fun saveCustomPhoto(lookupKey: String, source: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = context.contentResolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            val side = minOf(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
            val file = File(photoDir, "fav_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            val old = dao.get(lookupKey)
            old?.customPhotoPath?.let { File(it).delete() }
            dao.put(FavouriteMetaEntity(lookupKey, old?.sortIndex ?: (dao.maxIndex() + 1), file.absolutePath))
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun clearCustomPhoto(lookupKey: String) {
        val old = dao.get(lookupKey) ?: return
        old.customPhotoPath?.let { File(it).delete() }
        dao.put(old.copy(customPhotoPath = null))
    }

    suspend fun clearAll() {
        photoDir.listFiles()?.forEach { it.delete() }
        dao.clear()
    }
}
