package com.pulse.dialer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pulse.dialer.container
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.data.RecordingEntity
import com.pulse.dialer.data.model.SimInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val c = app.container

    val settings: StateFlow<AppSettings> = c.settings.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _sims = MutableStateFlow<List<SimInfo>>(emptyList())
    val sims: StateFlow<List<SimInfo>> = _sims.asStateFlow()

    val recordings: StateFlow<List<RecordingEntity>> = c.recordings.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val recordingBytes: StateFlow<Long> = c.recordings.observeTotalBytes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    init {
        refreshSims()
    }

    fun refreshSims() {
        viewModelScope.launch { _sims.value = withContext(Dispatchers.IO) { c.sims.activeSims() } }
    }

    fun setTheme(v: String) = viewModelScope.launch { c.settings.setTheme(v) }
    fun setHaptics(v: Boolean) = viewModelScope.launch { c.settings.setHaptics(v) }
    fun setDialTones(v: Boolean) = viewModelScope.launch { c.settings.setDialTones(v) }
    fun setDefaultSim(v: String) = viewModelScope.launch { c.settings.setDefaultSim(v) }
    fun setAutoRecordUnknown(v: Boolean) = viewModelScope.launch { c.settings.setAutoRecordUnknown(v) }
    fun setAutoRecordSaved(v: Boolean) = viewModelScope.launch { c.settings.setAutoRecordSaved(v) }
    fun setRetentionDays(v: Int) = viewModelScope.launch { c.settings.setRetentionDays(v) }
    fun setMissedNotifications(v: Boolean) = viewModelScope.launch { c.settings.setMissedNotifications(v) }
    fun setRejectBlocked(v: Boolean) = viewModelScope.launch { c.settings.setRejectBlocked(v) }
    fun setOnboardingDone() = viewModelScope.launch { c.settings.setOnboardingDone(true) }
    fun enableRecording() = viewModelScope.launch { c.settings.enableRecording() }
    fun disableRecording() = viewModelScope.launch { c.settings.disableRecording() }

    fun deleteRecording(r: RecordingEntity) {
        viewModelScope.launch(Dispatchers.IO) { c.recordings.delete(r) }
    }

    fun deleteAllRecordings() {
        viewModelScope.launch(Dispatchers.IO) { c.recordings.deleteAll() }
    }

    fun clearNotes() {
        viewModelScope.launch(Dispatchers.IO) { c.notes.clear() }
    }

    /** Wipes everything Pulse stores itself (notes, block list, favourite extras, recordings, settings). */
    fun deleteAllAppData() {
        viewModelScope.launch(Dispatchers.IO) {
            c.recordings.deleteAll()
            c.notes.clear()
            c.blocked.clear()
            c.favourites.clearAll()
            c.settings.resetAll()
        }
    }
}
