package com.pulse.dialer.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "call_notes")
data class CallNoteEntity(
    @PrimaryKey val callLogId: Long,
    val number: String,
    val note: String,
    val updatedAt: Long
)

@Entity(tableName = "blocked_numbers")
data class BlockedNumberEntity(
    @PrimaryKey val matchKey: String,
    val number: String,
    val addedAt: Long
)

@Entity(tableName = "favourite_meta")
data class FavouriteMetaEntity(
    @PrimaryKey val lookupKey: String,
    val sortIndex: Int,
    val customPhotoPath: String?
)

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val number: String,
    val contactName: String?,
    val isIncoming: Boolean,
    val isUnknownCaller: Boolean,
    val startedAt: Long,
    val durationMs: Long,
    val sizeBytes: Long,
    val simLabel: String?,
    val audioSource: String
)

@Dao
interface CallNoteDao {
    @Query("SELECT * FROM call_notes")
    fun observeAll(): Flow<List<CallNoteEntity>>

    @Query("SELECT * FROM call_notes WHERE callLogId = :id LIMIT 1")
    suspend fun get(id: Long): CallNoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(note: CallNoteEntity)

    @Query("DELETE FROM call_notes WHERE callLogId = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM call_notes")
    suspend fun clear()
}

@Dao
interface BlockedDao {
    @Query("SELECT * FROM blocked_numbers ORDER BY addedAt DESC")
    fun observeAll(): Flow<List<BlockedNumberEntity>>

    @Query("SELECT * FROM blocked_numbers WHERE matchKey = :key LIMIT 1")
    suspend fun get(key: String): BlockedNumberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: BlockedNumberEntity)

    @Query("DELETE FROM blocked_numbers WHERE matchKey = :key")
    suspend fun delete(key: String)

    @Query("DELETE FROM blocked_numbers")
    suspend fun clear()
}

@Dao
interface FavouriteDao {
    @Query("SELECT * FROM favourite_meta")
    fun observeAll(): Flow<List<FavouriteMetaEntity>>

    @Query("SELECT * FROM favourite_meta WHERE lookupKey = :key LIMIT 1")
    suspend fun get(key: String): FavouriteMetaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(entity: FavouriteMetaEntity)

    @Query("DELETE FROM favourite_meta WHERE lookupKey = :key")
    suspend fun delete(key: String)

    @Query("SELECT COALESCE(MAX(sortIndex), -1) FROM favourite_meta")
    suspend fun maxIndex(): Int

    @Query("SELECT * FROM favourite_meta")
    suspend fun all(): List<FavouriteMetaEntity>

    @Query("DELETE FROM favourite_meta")
    suspend fun clear()
}

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY startedAt DESC")
    fun observeAll(): Flow<List<RecordingEntity>>

    @Query("SELECT * FROM recordings")
    suspend fun all(): List<RecordingEntity>

    @Query("SELECT * FROM recordings WHERE startedAt < :cutoff")
    suspend fun olderThan(cutoff: Long): List<RecordingEntity>

    @Insert
    suspend fun insert(entity: RecordingEntity): Long

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM recordings")
    suspend fun clear()
}

@Database(
    entities = [CallNoteEntity::class, BlockedNumberEntity::class, FavouriteMetaEntity::class, RecordingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun callNotes(): CallNoteDao
    abstract fun blocked(): BlockedDao
    abstract fun favourites(): FavouriteDao
    abstract fun recordings(): RecordingDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "pulse.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
