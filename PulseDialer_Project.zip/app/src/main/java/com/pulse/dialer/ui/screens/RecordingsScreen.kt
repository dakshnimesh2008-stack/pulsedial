package com.pulse.dialer.ui.screens

import android.media.MediaPlayer
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.data.RecordingEntity
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.InfoCard
import com.pulse.dialer.ui.components.Pill
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.TimeUtils
import com.pulse.dialer.viewmodel.SettingsViewModel
import kotlinx.coroutines.delay

private class RecordingPlayer {
    private var player: MediaPlayer? = null
    var currentId by mutableLongStateOf(-1L)
    var isPlaying by mutableStateOf(false)
    var positionMs by mutableIntStateOf(0)
    var durationMs by mutableIntStateOf(0)

    fun toggle(rec: RecordingEntity) {
        val p = player
        if (p != null && currentId == rec.id) {
            if (p.isPlaying) {
                p.pause()
                isPlaying = false
            } else {
                p.start()
                isPlaying = true
            }
            return
        }
        release()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(rec.filePath)
            mp.prepare()
            mp.setOnCompletionListener {
                isPlaying = false
                positionMs = 0
                it.seekTo(0)
            }
            mp.start()
            player = mp
            currentId = rec.id
            durationMs = mp.duration
            positionMs = 0
            isPlaying = true
        } catch (e: Exception) {
            release()
        }
    }

    fun tick() {
        player?.let { positionMs = it.currentPosition }
    }

    fun seek(ms: Int) {
        player?.seekTo(ms)
        positionMs = ms
    }

    fun release() {
        player?.let {
            runCatching { it.stop() }
            runCatching { it.release() }
        }
        player = null
        currentId = -1L
        isPlaying = false
        positionMs = 0
    }
}

@Composable
fun RecordingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val recordings by vm.recordings.collectAsStateWithLifecycle()
    val totalBytes by vm.recordingBytes.collectAsStateWithLifecycle()
    val player = remember { RecordingPlayer() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.tick()
            delay(250)
        }
    }
    var confirmAll by remember { mutableStateOf(false) }
    var confirmOne by remember { mutableStateOf<RecordingEntity?>(null) }
    val free = remember(totalBytes) { runCatching { StatFs(context.filesDir.path).availableBytes }.getOrDefault(0L) }

    SubScreen(
        title = "Recordings",
        onBack = onBack,
        actions = {
            if (recordings.isNotEmpty()) {
                IconButton(onClick = { confirmAll = true }) { Icon(Icons.Default.Delete, contentDescription = "Delete all recordings") }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Storage used", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(TimeUtils.bytes(totalBytes), style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        val fraction = if (totalBytes + free == 0L) 0f else totalBytes.toFloat() / (totalBytes + free).toFloat()
                        LinearProgressIndicator(progress = { fraction.coerceIn(0.01f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "${recordings.size} recording${if (recordings.size == 1) "" else "s"} · ${TimeUtils.bytes(free)} free on this phone",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                InfoCard(
                    "About call recording",
                    "Android doesn't let ordinary apps capture the other person's voice on most phones. When only the microphone is available, a recording may contain just your side (or both sides if speakerphone is on). Pulse checks that audio really was captured and never saves empty files."
                )
            }
            if (recordings.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().height(320.dp)) {
                        EmptyState(Icons.Default.Mic, "No recordings", "Recordings you make during calls appear here. Turn recording on in Settings.")
                    }
                }
            } else {
                items(recordings, key = { it.id }) { r ->
                    val title = r.contactName ?: PhoneUtils.format(r.number).ifBlank { "Private number" }
                    val active = player.currentId == r.id
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { player.toggle(r) }) {
                                Icon(
                                    if (active && player.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (active && player.isPlaying) "Pause" else "Play",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Column(Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                                Text(
                                    "${TimeUtils.dateTime(context, r.startedAt)} · ${TimeUtils.spoken(r.durationMs / 1000)} · ${TimeUtils.bytes(r.sizeBytes)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                                    Pill(if (r.isIncoming) "Incoming" else "Outgoing", MaterialTheme.colorScheme.primary)
                                    if (r.isUnknownCaller) Pill("Unknown caller", PulseColors.Amber)
                                    Pill(r.audioSource, if (r.audioSource == "Call audio") PulseColors.CallGreen else PulseColors.Amber)
                                }
                            }
                            IconButton(onClick = { confirmOne = r }) { Icon(Icons.Default.Delete, contentDescription = "Delete recording") }
                        }
                        if (active && player.durationMs > 0) {
                            Slider(
                                value = player.positionMs.toFloat(),
                                onValueChange = { player.seek(it.toInt()) },
                                valueRange = 0f..player.durationMs.toFloat()
                            )
                        }
                    }
                }
            }
        }
    }

    confirmOne?.let { r ->
        AlertDialog(
            onDismissRequest = { confirmOne = null },
            title = { Text("Delete this recording?") },
            text = { Text("The audio file is permanently removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    if (player.currentId == r.id) player.release()
                    vm.deleteRecording(r)
                    confirmOne = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmOne = null }) { Text("Cancel") } }
        )
    }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Delete all recordings?") },
            text = { Text("All ${recordings.size} recordings are permanently removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    player.release()
                    vm.deleteAllRecordings()
                    confirmAll = false
                }) { Text("Delete all") }
            },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel") } }
        )
    }
}
