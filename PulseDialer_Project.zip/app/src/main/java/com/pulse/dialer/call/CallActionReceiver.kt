package com.pulse.dialer.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.pulse.dialer.recording.RecordingController

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_DECLINE -> CallManager.rejectRinging()
            ACTION_HANGUP -> CallManager.hangupPrimary()
            ACTION_STOP_RECORDING -> RecordingController.stop(context)
            ACTION_CALLBACK -> {
                val number = intent.getStringExtra(EXTRA_NUMBER) ?: return
                CallLauncher.place(context, number, null)
                CallNotifications.cancelMissed(context, number)
            }
        }
    }

    companion object {
        const val ACTION_DECLINE = "com.pulse.dialer.action.DECLINE"
        const val ACTION_HANGUP = "com.pulse.dialer.action.HANGUP"
        const val ACTION_STOP_RECORDING = "com.pulse.dialer.action.STOP_RECORDING"
        const val ACTION_CALLBACK = "com.pulse.dialer.action.CALLBACK"
        const val EXTRA_NUMBER = "number"
    }
}
