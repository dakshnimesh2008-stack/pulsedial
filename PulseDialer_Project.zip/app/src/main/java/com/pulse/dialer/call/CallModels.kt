package com.pulse.dialer.call

import android.telecom.CallAudioState

enum class CallUiState { Connecting, Dialing, Ringing, Active, Holding, Disconnecting }

data class CallInfo(
    val key: Int,
    val number: String,
    val name: String?,
    val photoUri: String?,
    val isUnknown: Boolean,
    val isIncoming: Boolean,
    val state: CallUiState,
    val connectTimeMillis: Long,
    val simLabel: String?,
    val isConference: Boolean,
    val conferenceSize: Int,
    val canHold: Boolean,
    val canMerge: Boolean
)

data class EndedInfo(
    val name: String?,
    val number: String,
    val photoUri: String?,
    val durationSeconds: Long,
    val wasMissed: Boolean
)

data class AudioInfo(
    val route: Int = CallAudioState.ROUTE_EARPIECE,
    val supported: Int = CallAudioState.ROUTE_EARPIECE,
    val muted: Boolean = false
) {
    val hasBluetooth: Boolean get() = supported and CallAudioState.ROUTE_BLUETOOTH != 0
    val hasWired: Boolean get() = supported and CallAudioState.ROUTE_WIRED_HEADSET != 0
    val speakerOn: Boolean get() = route == CallAudioState.ROUTE_SPEAKER
}
