package com.pulse.dialer.ui.screens

import android.Manifest
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.data.model.PhoneEntry
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.viewmodel.ContactsViewModel

private class EditPhone(val dataId: Long, number: String, type: Int) {
    var number by mutableStateOf(number)
    var type by mutableStateOf(type)
}

private val typeCycle = listOf(
    Phone.TYPE_MOBILE to "Mobile",
    Phone.TYPE_HOME to "Home",
    Phone.TYPE_WORK to "Work",
    Phone.TYPE_OTHER to "Other"
)

/** Adds a new contact (contactId = -1, optionally with a prefilled number) or edits an existing one. */
@Composable
fun ContactEditScreen(
    contactId: Long,
    prefillNumber: String,
    vm: ContactsViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val existing = if (contactId >= 0) contacts.firstOrNull { it.id == contactId } else null
    var name by remember(existing?.id) { mutableStateOf(existing?.name ?: "") }
    val phones = remember(existing?.id) {
        mutableStateListOf<EditPhone>().apply {
            if (existing != null) existing.phones.forEach { add(EditPhone(it.dataId, it.number, it.type)) }
            else add(EditPhone(0L, prefillNumber, Phone.TYPE_MOBILE))
        }
    }

    fun doSave() {
        val cleaned = phones.filter { it.number.isNotBlank() }
            .map { PhoneEntry(it.dataId, it.number.trim(), it.type, null) }
        if (name.isBlank() && cleaned.isEmpty()) {
            Toast.makeText(context, "Enter a name or a number", Toast.LENGTH_SHORT).show()
            return
        }
        vm.save(existing, name.trim(), cleaned) { ok ->
            if (ok) onBack() else Toast.makeText(context, "Could not save the contact", Toast.LENGTH_SHORT).show()
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) doSave() else Toast.makeText(context, "Saving contacts needs the Contacts permission", Toast.LENGTH_SHORT).show()
    }

    SubScreen(
        title = if (existing == null) "New contact" else "Edit contact",
        onBack = onBack,
        actions = {
            TextButton(onClick = {
                if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CONTACTS) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                ) doSave() else permission.launch(Manifest.permission.WRITE_CONTACTS)
            }) { Text("Save") }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            phones.forEachIndexed { index, p ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = p.number, onValueChange = { p.number = it },
                        label = { Text("Phone") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.weight(1f)
                    )
                    val typeName = typeCycle.firstOrNull { it.first == p.type }?.second ?: "Other"
                    AssistChip(
                        onClick = {
                            val i = typeCycle.indexOfFirst { it.first == p.type }
                            p.type = typeCycle[(i + 1).mod(typeCycle.size)].first
                        },
                        label = { Text(typeName) },
                        modifier = Modifier.padding(start = 8.dp)
                    )
                    if (phones.size > 1) {
                        IconButton(onClick = { phones.removeAt(index) }) {
                            Icon(Icons.Default.Close, contentDescription = "Remove number")
                        }
                    }
                }
            }
            TextButton(onClick = { phones.add(EditPhone(0L, "", Phone.TYPE_MOBILE)) }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.height(0.dp))
                Text("  Add another number")
            }
            Text(
                "Contacts are stored in your phone's own contacts database, not in Pulse.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
