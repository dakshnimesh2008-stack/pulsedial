package com.pulse.dialer.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pulse.dialer.container
import com.pulse.dialer.data.model.Contact
import com.pulse.dialer.data.model.FavouriteItem
import com.pulse.dialer.data.model.PhoneEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalCoroutinesApi::class)
class ContactsViewModel(app: Application) : AndroidViewModel(app) {
    private val c = app.container
    private val tick = MutableStateFlow(0)
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val contacts: StateFlow<List<Contact>> = tick
        .flatMapLatest { c.contacts.observe() }
        .onEach { _loading.value = false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val favourites: StateFlow<List<FavouriteItem>> =
        combine(contacts, c.favourites.observeAll()) { list, metas ->
            val byKey = metas.associateBy { it.lookupKey }
            list.filter { it.starred }
                .map { ct ->
                    val meta = byKey[ct.lookupKey]
                    FavouriteItem(ct, meta?.customPhotoPath?.let { p -> "file://$p" }, meta?.sortIndex ?: Int.MAX_VALUE)
                }
                .sortedWith(compareBy<FavouriteItem> { it.sortIndex }.thenBy { it.contact.name.lowercase() })
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Re-subscribes after a permission change so the content observer is registered. */
    fun refresh() {
        tick.value += 1
    }

    fun toggleFavourite(contact: Contact) {
        viewModelScope.launch {
            val newValue = !contact.starred
            withContext(Dispatchers.IO) {
                c.contacts.setStarred(contact.id, newValue)
                if (newValue) c.favourites.ensureMeta(contact.lookupKey) else c.favourites.removeMeta(contact.lookupKey)
            }
        }
    }

    fun moveFavourite(item: FavouriteItem, delta: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val keys = favourites.value.map { it.contact.lookupKey }.toMutableList()
            val from = keys.indexOf(item.contact.lookupKey)
            val to = from + delta
            if (from < 0 || to !in keys.indices) return@launch
            keys.add(to, keys.removeAt(from))
            c.favourites.saveOrder(keys)
        }
    }

    fun setCustomPhoto(item: FavouriteItem, uri: Uri) {
        viewModelScope.launch { c.favourites.saveCustomPhoto(item.contact.lookupKey, uri) }
    }

    fun clearCustomPhoto(item: FavouriteItem) {
        viewModelScope.launch { c.favourites.clearCustomPhoto(item.contact.lookupKey) }
    }

    fun save(existing: Contact?, name: String, phones: List<PhoneEntry>, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                if (existing == null) c.contacts.create(name, phones) else c.contacts.update(existing, name, phones)
            }
            onDone(ok)
        }
    }

    fun delete(contact: Contact, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val deleted = c.contacts.delete(contact.lookupKey)
                if (deleted) c.favourites.removeMeta(contact.lookupKey)
                deleted
            }
            onDone(ok)
        }
    }
}
