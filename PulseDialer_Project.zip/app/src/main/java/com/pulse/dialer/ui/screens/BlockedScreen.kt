package com.pulse.dialer.ui.screens

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.viewmodel.HistoryViewModel

@Composable
fun BlockedScreen(vm: HistoryViewModel, onBack: () -> Unit) {
    val blocked by vm.blocked.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    SubScreen(title = "Blocked numbers", onBack = onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    label = { Text("Add a number") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        vm.block(input.trim())
                        input = ""
                    },
                    enabled = PhoneUtils.digits(input).length >= 3,
                    modifier = Modifier.padding(start = 12.dp)
                ) { Text("Block") }
            }
            Text(
                "Blocked callers are rejected before they ring. When Pulse is your default phone app, numbers are also added to Android's own block list.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            if (blocked.isEmpty()) {
                EmptyState(Icons.Default.Block, "Nothing blocked", "Block a number from a call's details screen or add one above.")
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(blocked, key = { it.matchKey }) { b ->
                        ListItem(
                            headlineContent = { Text(PhoneUtils.format(b.number)) },
                            leadingContent = { Icon(Icons.Default.Block, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            trailingContent = {
                                IconButton(onClick = { vm.unblock(b.number) }) {
                                    Icon(Icons.Default.Close, contentDescription = "Unblock ${b.number}")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
