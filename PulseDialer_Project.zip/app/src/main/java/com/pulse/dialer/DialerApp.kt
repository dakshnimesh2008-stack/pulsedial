package com.pulse.dialer

import android.app.Application
import android.content.Context
import com.pulse.dialer.call.CallNotifications
import com.pulse.dialer.data.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DialerApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        CallNotifications.createChannels(this)
        // Honour the user's recording-retention choice on every start.
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            runCatching {
                val days = container.settings.current().retentionDays
                if (days > 0) container.recordings.purgeOlderThan(days)
            }
        }
    }
}

val Context.container: AppContainer
    get() = (applicationContext as DialerApp).container
