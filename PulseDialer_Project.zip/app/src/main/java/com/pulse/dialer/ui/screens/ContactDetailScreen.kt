package com.pulse.dialer.ui.screens

import android.provider.ContactsContract
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.LocalDial
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.ui.components.copyText
import com.pulse.dialer.ui.components.sendSms
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.viewmodel.ContactsViewModel

@Composable
fun ContactDetailScreen(
    id: Long,
    vm: ContactsViewModel,
    onBack: () -> Unit,
    onEdit: (Long) -> Unit
) {
    val context = LocalContext.current
    val dial = LocalDial.current
    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val contact = contacts.firstOrNull { it.id == id }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(contact == null && !loading) {
        if (contact == null && !loading) onBack()
    }

    SubScreen(
        title = "",
        onBack = onBack,
        actions = {
            if (contact != null) {
                IconButton(onClick = { onEdit(contact.id) }) { Icon(Icons.Default.Edit, contentDescription = "Edit contact") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "More options") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Delete contact") },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                            onClick = {
                                menu = false
                                confirmDelete = true
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        if (contact == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@SubScreen
        }
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ContactAvatar(contact.name, contact.photoUri, 112.dp)
            Spacer(Modifier.height(14.dp))
            Text(contact.name, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 24.dp))
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                QuickAction(Icons.Default.Call, "Call") { contact.primaryNumber?.let { dial?.dial(it) } }
                QuickAction(Icons.Default.Message, "Message") { contact.primaryNumber?.let { sendSms(context, it) } }
                QuickAction(
                    if (contact.starred) Icons.Default.Star else Icons.Default.StarBorder,
                    if (contact.starred) "Favourite" else "Add favourite"
                ) { vm.toggleFavourite(contact) }
            }
            Spacer(Modifier.height(24.dp))
            contact.phones.forEach { p ->
                val type = ContactsContract.CommonDataKinds.Phone.getTypeLabel(context.resources, p.type, p.label).toString()
                Row(
                    Modifier.fillMaxWidth().clickable { dial?.dial(p.number) }.padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(PhoneUtils.format(p.number), style = MaterialTheme.typography.titleMedium)
                        Text(type, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { sendSms(context, p.number) }) { Icon(Icons.Default.Message, contentDescription = "Message ${p.number}") }
                    IconButton(onClick = { dial?.dial(p.number) }) {
                        Icon(Icons.Default.Call, contentDescription = "Call ${p.number}", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete && contact != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${contact.name}?") },
            text = { Text("This removes the contact from your phone's contacts.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(contact) { ok ->
                        if (!ok) android.widget.Toast.makeText(context, "Could not delete this contact", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
