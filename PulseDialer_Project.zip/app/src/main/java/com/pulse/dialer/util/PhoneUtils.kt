package com.pulse.dialer.util

import android.telephony.PhoneNumberUtils
import java.util.Locale

object PhoneUtils {
    fun digits(s: String): String = s.filter { it.isDigit() }

    /** Key used to compare numbers regardless of country code / formatting. */
    fun matchKey(number: String): String {
        val d = digits(number)
        return if (d.length > 10) d.takeLast(10) else d
    }

    fun sameNumber(a: String, b: String): Boolean {
        val ka = matchKey(a)
        val kb = matchKey(b)
        return ka.isNotEmpty() && ka == kb
    }

    fun strip(number: String): String = PhoneNumberUtils.stripSeparators(number) ?: number

    fun format(number: String): String {
        if (number.isBlank()) return ""
        if (number.any { it == '*' || it == '#' }) return number
        val country = Locale.getDefault().country
        if (country.isNullOrBlank()) return number
        return try {
            PhoneNumberUtils.formatNumber(number, country) ?: number
        } catch (e: Exception) {
            number
        }
    }
}
