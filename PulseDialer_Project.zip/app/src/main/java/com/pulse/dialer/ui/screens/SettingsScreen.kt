package com.pulse.dialer.ui.screens

import android.Manifest
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.R
import com.pulse.dialer.ui.components.InfoCard
import com.pulse.dialer.ui.components.SectionLabel
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.ui.components.rememberCorePermissionRequester
import com.pulse.dialer.ui.components.rememberDefaultDialerRequester
import com.pulse.dialer.ui.components.rememberIsDefaultDialer
import com.pulse.dialer.ui.components.rememberPerms
import com.pulse.dialer.util.TimeUtils
import com.pulse.dialer.viewmodel.SettingsViewModel

@Composable
private fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = subtitle?.let { { Text(it) } },
        leadingContent = { Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = trailing,
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    )
}

@Composable
private fun SettingSwitch(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    SettingRow(
        icon, title, subtitle,
        onClick = if (enabled) ({ onChange(!checked) }) else null,
        trailing = { Switch(checked = checked, onCheckedChange = if (enabled) onChange else null, enabled = enabled) }
    )
}

@Composable
private fun <T> ChoiceDialog(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            onSelect(value)
                            onDismiss()
                        }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = value == selected, onClick = {
                            onSelect(value)
                            onDismiss()
                        })
                        Text(label, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun SettingsScreen(
    vm: SettingsViewModel,
    onBack: () -> Unit,
    onOpenRecordings: () -> Unit,
    onOpenBlocked: () -> Unit
) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsStateWithLifecycle()
    val sims by vm.sims.collectAsStateWithLifecycle()
    val recordings by vm.recordings.collectAsStateWithLifecycle()
    val bytes by vm.recordingBytes.collectAsStateWithLifecycle()
    val perms = rememberPerms()
    val isDefault = rememberIsDefaultDialer()
    val requestPerms = rememberCorePermissionRequester()
    val requestDefault = rememberDefaultDialerRequester()

    var dialog by remember { mutableStateOf<String?>(null) }
    var consentChecked by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.enableRecording()
        else Toast.makeText(context, "Recording needs microphone access, so it stays off", Toast.LENGTH_LONG).show()
    }

    val versionName = remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0"
    }

    SubScreen(title = "Settings", onBack = onBack) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {

            SectionLabel("Phone app")
            SettingRow(
                Icons.Default.Call, "Default phone app",
                if (isDefault) "Pulse is your default phone app" else "Not set. Calls are handled by another app until you choose Pulse.",
                onClick = if (!isDefault) requestDefault else null,
                trailing = if (!isDefault) ({ Button(onClick = requestDefault) { Text("Set") } }) else null
            )
            SettingRow(
                Icons.Default.Security, "Permissions",
                if (perms.core) "Phone, contacts and call log access are on" else "Some access is off. Tap to review.",
                onClick = if (!perms.core) requestPerms else null
            )

            SectionLabel("Appearance")
            SettingRow(
                Icons.Default.DarkMode, "Theme",
                when (settings.theme) { "light" -> "Light"; "dark" -> "Dark"; else -> "System default" },
                onClick = { dialog = "theme" }
            )

            SectionLabel("Dialer")
            SettingSwitch(Icons.Default.Vibration, "Haptic feedback", "Subtle vibration on keypad presses", settings.haptics) { vm.setHaptics(it) }
            SettingSwitch(Icons.Default.Dialpad, "Keypad tones", "Play a short tone for each key", settings.dialTones) { vm.setDialTones(it) }

            SectionLabel("SIM cards")
            SettingRow(
                Icons.Default.SimCard, "Default SIM for calls",
                when {
                    settings.defaultSim == "ask" -> "Ask every time"
                    settings.defaultSim.startsWith("slot:") -> "SIM ${(settings.defaultSim.removePrefix("slot:").toIntOrNull() ?: 0) + 1}"
                    else -> "Follow Android's setting"
                },
                onClick = { dialog = "sim" }
            )
            SettingRow(
                Icons.Default.Info, "Detected SIMs",
                if (sims.isEmpty()) {
                    if (perms.phone) "No active SIM found" else "Allow the Phone permission to detect SIM cards"
                } else sims.joinToString("\n") { it.fullLabel }
            )

            SectionLabel("Unknown callers")
            SettingSwitch(
                Icons.Default.Block, "Reject blocked numbers", "Numbers on your block list never get to ring",
                settings.rejectBlocked
            ) { vm.setRejectBlocked(it) }
            SettingRow(Icons.Default.Block, "Blocked numbers", "Manage your block list", onClick = onOpenBlocked)
            Text(
                "Numbers that aren't in your contacts are labelled \"Unknown\". Pulse can't tell you who is really calling and has no online spam database.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            SectionLabel("Call recording")
            SettingSwitch(
                Icons.Default.Mic, "Enable call recording",
                "Off by default. A notification and an on-screen indicator show whenever a call is recorded.",
                settings.recordingEnabled
            ) { on ->
                if (on) {
                    consentChecked = false
                    dialog = "consent"
                } else vm.disableRecording()
            }
            SettingSwitch(
                Icons.Default.Mic, "Auto-record unknown incoming callers",
                "Only numbers that aren't in your contacts",
                settings.autoRecordUnknown, enabled = settings.recordingEnabled
            ) { vm.setAutoRecordUnknown(it) }
            SettingSwitch(
                Icons.Default.Mic, "Auto-record saved contacts",
                "Calls with people in your contacts",
                settings.autoRecordSaved, enabled = settings.recordingEnabled
            ) { vm.setAutoRecordSaved(it) }
            SettingRow(
                Icons.Default.Storage, "Recordings",
                "${recordings.size} saved · ${TimeUtils.bytes(bytes)}",
                onClick = onOpenRecordings
            )
            SettingRow(
                Icons.Default.Delete, "Keep recordings for",
                if (settings.retentionDays == 0) "Until I delete them" else "${settings.retentionDays} days",
                onClick = { dialog = "retention" }
            )
            Text(
                "Android doesn't guarantee that apps can capture call audio. Depending on your phone, a recording may contain only your voice, or may not be possible at all. Pulse says so when that happens.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )

            SectionLabel("Notifications")
            SettingSwitch(
                Icons.Default.Notifications, "Missed call notifications", "Show a notification with a call-back button",
                settings.missedNotifications
            ) { vm.setMissedNotifications(it) }
            SettingRow(
                Icons.Default.NotificationsActive, "System notification settings",
                if (perms.notifications) "Manage channels and sounds" else "Notifications are blocked. Incoming calls may not show on the lock screen.",
                onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    )
                }
            )

            SectionLabel("Privacy")
            SettingRow(
                Icons.Default.Lock, "Everything stays on this phone",
                "No account, no server, no internet permission, no analytics. Contacts and call log are read from Android and never copied elsewhere."
            )
            SettingRow(Icons.Default.PrivacyTip, "Delete all call notes", "Removes your private notes from call entries", onClick = { dialog = "notes" })
            SettingRow(
                Icons.Default.Delete, "Delete all Pulse data",
                "Notes, block list, favourite extras, recordings and settings",
                onClick = { dialog = "wipe" }
            )

            SectionLabel("About")
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.ic_badge), contentDescription = null, modifier = Modifier.size(56.dp))
                Column(Modifier.padding(start = 16.dp)) {
                    Text("Pulse Dialer", style = MaterialTheme.typography.titleMedium)
                    Text("Version $versionName", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            InfoCard(
                "Real calls, no internet",
                "Calls go through your SIM and mobile network using Android's own telephony. Pulse works fully offline."
            )
            Spacer(Modifier.height(32.dp))
        }
    }

    when (dialog) {
        "theme" -> ChoiceDialog(
            "Theme",
            listOf("system" to "System default", "light" to "Light", "dark" to "Dark"),
            settings.theme, { vm.setTheme(it) }, { dialog = null }
        )
        "sim" -> ChoiceDialog(
            "Default SIM for calls",
            buildList {
                add("system" to "Follow Android's setting")
                add("ask" to "Ask every time")
                sims.forEach { add("slot:${it.slotIndex}" to it.fullLabel) }
            },
            settings.defaultSim, { vm.setDefaultSim(it) }, { dialog = null }
        )
        "retention" -> ChoiceDialog(
            "Keep recordings for",
            listOf(0 to "Until I delete them", 7 to "7 days", 30 to "30 days", 90 to "90 days"),
            settings.retentionDays, { vm.setRetentionDays(it) }, { dialog = null }
        )
        "consent" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Before you turn on recording") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("• Recording calls is regulated by law. In many places you must tell the other person and get their consent.")
                    Spacer(Modifier.height(8.dp))
                    Text("• Pulse never records secretly. A notification and an on-screen \"REC\" indicator show whenever a call is being recorded.")
                    Spacer(Modifier.height(8.dp))
                    Text("• Android blocks most apps from capturing the other person's voice. Pulse tries, checks that sound was really captured, and tells you when it wasn't.")
                    Spacer(Modifier.height(8.dp))
                    Text("• Recordings stay on this phone and are never uploaded.")
                    Row(
                        Modifier.fillMaxWidth().clickable { consentChecked = !consentChecked }.padding(top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = consentChecked, onCheckedChange = { consentChecked = it })
                        Text("I understand and will follow the law where I am.", modifier = Modifier.padding(start = 8.dp))
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = consentChecked,
                    onClick = {
                        dialog = null
                        if (perms.record) vm.enableRecording() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                ) { Text("Turn on") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        "notes" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Delete all call notes?") },
            text = { Text("Your private notes are removed. Call history itself is not touched.") },
            confirmButton = { TextButton(onClick = { vm.clearNotes(); dialog = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
        "wipe" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Delete all Pulse data?") },
            text = { Text("Notes, block list, favourite photos and order, recordings and settings are erased. Your contacts and call log are not touched.") },
            confirmButton = { TextButton(onClick = { vm.deleteAllAppData(); dialog = null }) { Text("Delete everything") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } }
        )
    }
}
