package com.pulse.dialer.data

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.database.ContentObserver
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import com.pulse.dialer.data.model.CallEntry
import com.pulse.dialer.data.model.CallKind
import com.pulse.dialer.util.Permissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/** Reads Android's system call log. The log itself is written by Android Telecom, not by this app. */
class CallLogRepository(private val context: Context, private val sims: SimRepository) {
    private val resolver get() = context.contentResolver

    private companion object {
        const val MAX_ROWS = 1000
    }

    fun hasRead() = Permissions.granted(context, Manifest.permission.READ_CALL_LOG)
    fun hasWrite() = Permissions.granted(context, Manifest.permission.WRITE_CALL_LOG)

    fun observe(): Flow<List<CallEntry>> = callbackFlow<Unit> {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        if (hasRead()) resolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, observer)
        trySend(Unit)
        awaitClose { resolver.unregisterContentObserver(observer) }
    }.conflate().map { load() }.flowOn(Dispatchers.IO)

    private fun kindOf(type: Int): CallKind = when (type) {
        CallLog.Calls.INCOMING_TYPE, CallLog.Calls.ANSWERED_EXTERNALLY_TYPE -> CallKind.Incoming
        CallLog.Calls.OUTGOING_TYPE -> CallKind.Outgoing
        CallLog.Calls.MISSED_TYPE -> CallKind.Missed
        CallLog.Calls.REJECTED_TYPE -> CallKind.Rejected
        CallLog.Calls.BLOCKED_TYPE -> CallKind.Blocked
        CallLog.Calls.VOICEMAIL_TYPE -> CallKind.Voicemail
        else -> CallKind.Other
    }

    private fun load(): List<CallEntry> {
        if (!hasRead()) return emptyList()
        val simList = sims.activeSims()
        val projection = arrayOf(
            CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
            CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.PHONE_ACCOUNT_ID
        )
        val args = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${CallLog.Calls.DATE} DESC")
        }
        val out = ArrayList<CallEntry>()
        try {
            resolver.query(CallLog.Calls.CONTENT_URI, projection, args, null)?.use { c ->
                while (c.moveToNext() && out.size < MAX_ROWS) {
                    out.add(
                        CallEntry(
                            id = c.getLong(0),
                            number = c.getString(1).orEmpty(),
                            cachedName = c.getString(2),
                            kind = kindOf(c.getInt(3)),
                            dateMillis = c.getLong(4),
                            durationSec = c.getLong(5),
                            simLabel = sims.labelForAccountId(simList, c.getString(6))
                        )
                    )
                }
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    suspend fun delete(id: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            resolver.delete(CallLog.Calls.CONTENT_URI, "${CallLog.Calls._ID}=?", arrayOf(id.toString())) > 0
        } catch (e: Exception) {
            false
        }
    }

    suspend fun clear(): Boolean = withContext(Dispatchers.IO) {
        try {
            resolver.delete(CallLog.Calls.CONTENT_URI, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun lastOutgoing(): String? = withContext(Dispatchers.IO) {
        try {
            if (hasRead()) CallLog.Calls.getLastOutgoingCall(context)?.takeIf { it.isNotBlank() } else null
        } catch (e: Exception) {
            null
        }
    }
}
