package com.pulse.dialer.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

data class Perms(
    val contacts: Boolean,
    val writeContacts: Boolean,
    val callLog: Boolean,
    val phone: Boolean,
    val callPhone: Boolean,
    val notifications: Boolean,
    val record: Boolean
) {
    val core: Boolean get() = contacts && callLog && callPhone && phone
}

object Permissions {
    fun granted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun check(context: Context) = Perms(
        contacts = granted(context, Manifest.permission.READ_CONTACTS),
        writeContacts = granted(context, Manifest.permission.WRITE_CONTACTS),
        callLog = granted(context, Manifest.permission.READ_CALL_LOG),
        phone = granted(context, Manifest.permission.READ_PHONE_STATE),
        callPhone = granted(context, Manifest.permission.CALL_PHONE),
        notifications = Build.VERSION.SDK_INT < 33 || granted(context, Manifest.permission.POST_NOTIFICATIONS),
        record = granted(context, Manifest.permission.RECORD_AUDIO)
    )

    /** Everything the dialer needs for normal operation (recording mic permission is requested separately). */
    val coreRequest: Array<String> = buildList {
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.WRITE_CONTACTS)
        add(Manifest.permission.READ_CALL_LOG)
        add(Manifest.permission.WRITE_CALL_LOG)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_PHONE_STATE)
        add(Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()
}
