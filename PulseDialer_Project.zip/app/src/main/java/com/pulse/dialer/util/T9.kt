package com.pulse.dialer.util

/** Helpers for T9 (phone keypad letter) contact search. */
object T9 {
    private val groups = mapOf(
        '2' to "abc", '3' to "def", '4' to "ghi", '5' to "jkl",
        '6' to "mno", '7' to "pqrs", '8' to "tuv", '9' to "wxyz"
    )
    private val letterToDigit: Map<Char, Char> =
        groups.flatMap { (digit, letters) -> letters.map { it to digit } }.toMap()

    fun lettersFor(digit: Char): String = groups[digit]?.uppercase() ?: ""

    fun fromText(text: String): String = buildString {
        for (c in text.lowercase()) {
            val d = letterToDigit[c]
            if (d != null) append(d) else if (c.isDigit()) append(c)
        }
    }

    /** True when the typed digits match the start of the name, of any word in it, or of its initials. */
    fun matches(name: String, query: String): Boolean {
        if (query.isEmpty() || query.any { !it.isDigit() }) return false
        val words = name.split(' ', '-', '.', '_').filter { it.isNotBlank() }
        if (words.isEmpty()) return false
        if (words.any { fromText(it).startsWith(query) }) return true
        if (fromText(words.joinToString("")).startsWith(query)) return true
        val initials = words.mapNotNull { fromText(it.take(1)).firstOrNull() }.joinToString("")
        return initials.startsWith(query)
    }
}
