package com.pulse.dialer.ui.screens

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.container
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.data.model.SimInfo
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.LocalDial
import com.pulse.dialer.ui.components.TabScaffold
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.T9
import com.pulse.dialer.viewmodel.ContactsViewModel
import com.pulse.dialer.viewmodel.HistoryViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private class KeyTones {
    private val generator: ToneGenerator? = runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 70) }.getOrNull()

    fun play(key: Char) {
        val tone = when (key) {
            '0' -> ToneGenerator.TONE_DTMF_0
            '1' -> ToneGenerator.TONE_DTMF_1
            '2' -> ToneGenerator.TONE_DTMF_2
            '3' -> ToneGenerator.TONE_DTMF_3
            '4' -> ToneGenerator.TONE_DTMF_4
            '5' -> ToneGenerator.TONE_DTMF_5
            '6' -> ToneGenerator.TONE_DTMF_6
            '7' -> ToneGenerator.TONE_DTMF_7
            '8' -> ToneGenerator.TONE_DTMF_8
            '9' -> ToneGenerator.TONE_DTMF_9
            '*' -> ToneGenerator.TONE_DTMF_S
            '#' -> ToneGenerator.TONE_DTMF_P
            else -> return
        }
        generator?.startTone(tone, 90)
    }

    fun release() {
        generator?.release()
    }
}

@Composable
fun KeypadScreen(
    prefill: String?,
    onPrefillConsumed: () -> Unit,
    settings: AppSettings,
    sims: List<SimInfo>,
    contactsVm: ContactsViewModel,
    historyVm: HistoryViewModel,
    onSettings: () -> Unit,
    onAddContact: (String) -> Unit,
    onOpenContact: (Long) -> Unit
) {
    val context = LocalContext.current
    val dial = LocalDial.current
    val haptic = LocalHapticFeedback.current
    val contacts by contactsVm.contacts.collectAsStateWithLifecycle()
    var number by rememberSaveable { mutableStateOf("") }
    val tones = remember { KeyTones() }
    DisposableEffect(Unit) { onDispose { tones.release() } }

    LaunchedEffect(prefill) {
        if (prefill != null) {
            number = prefill
            onPrefillConsumed()
        }
    }

    val systemAsks = remember(sims) { sims.size >= 2 && context.container.sims.defaultOutgoingHandle() == null }
    val showDual = sims.size >= 2 && (settings.defaultSim == "ask" || (settings.defaultSim == "system" && systemAsks))

    val q = number.filter { it.isDigit() }
    val matches = remember(number, contacts) {
        if (q.isEmpty()) emptyList() else contacts.filter { ct ->
            (q.length >= 2 && ct.phones.any { PhoneUtils.digits(it.number).contains(q) }) || T9.matches(ct.name, q)
        }.take(20)
    }
    val exact = remember(number, contacts) {
        if (q.length < 5) null else contacts.firstOrNull { ct ->
            ct.phones.any { PhoneUtils.matchKey(it.number) == PhoneUtils.matchKey(number) }
        }
    }

    fun press(ch: Char) {
        if (settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (settings.dialTones) tones.play(ch)
        if (number.length < 32) number += ch
    }

    fun deleteOne() {
        if (settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        number = number.dropLast(1)
    }

    fun callWith(sim: SimInfo?) {
        if (number.isBlank()) {
            historyVm.lastOutgoing { last -> if (last != null) number = last }
            return
        }
        if (sim != null) dial?.dialWith(number, sim) else dial?.dial(number)
        number = ""
    }

    TabScaffold(title = "Keypad", onSettings = onSettings) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val keySize = minOf(80.dp, (maxWidth - 120.dp) / 3, ((maxHeight - 330.dp) / 4).coerceAtLeast(52.dp))
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                // Suggestions: instant contact matches while typing
                Box(Modifier.fillMaxWidth().height(64.dp), contentAlignment = Alignment.CenterStart) {
                    if (matches.isNotEmpty()) {
                        LazyRow(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(matches, key = { it.id }) { ct ->
                                val hit = ct.phones.firstOrNull { PhoneUtils.digits(it.number).contains(q) } ?: ct.phones.first()
                                Row(
                                    Modifier.clip(RoundedCornerShape(24.dp))
                                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                        .clickable { number = PhoneUtils.strip(hit.number) }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ContactAvatar(ct.name, ct.photoUri, 36.dp)
                                    Column(Modifier.padding(start = 10.dp, end = 6.dp)) {
                                        Text(ct.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(PhoneUtils.format(hit.number), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                    }
                                }
                            }
                        }
                    } else if (number.length >= 3 && exact == null) {
                        TextButton(onClick = { onAddContact(number) }, modifier = Modifier.padding(start = 8.dp)) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.size(8.dp))
                            Text("Add to contacts")
                        }
                    } else if (number.isEmpty()) {
                        Text(
                            "Type a number, or letters-as-digits to find a contact",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp)
                        )
                    }
                }

                // Number display
                Box(Modifier.fillMaxWidth().height(84.dp).padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 56.dp)) {
                        val shown = if (number.all { it.isDigit() || it == '+' }) PhoneUtils.format(number) else number
                        Text(
                            shown,
                            fontSize = when {
                                shown.length > 16 -> 24.sp
                                shown.length > 12 -> 30.sp
                                else -> 38.sp
                            },
                            fontWeight = FontWeight.Light,
                            maxLines = 1,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.semantics { contentDescription = "Number: $number" }
                        )
                        exact?.let {
                            Text(it.name, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        }
                    }
                    if (number.isNotEmpty()) {
                        BackspaceKey(onDelete = { deleteOne() }, modifier = Modifier.align(Alignment.CenterEnd))
                        if (number.length > 4) {
                            TextButton(onClick = { number = "" }, modifier = Modifier.align(Alignment.CenterStart)) { Text("Clear") }
                        }
                    }
                }

                Spacer(Modifier.weight(1f))

                val rows = listOf(listOf('1', '2', '3'), listOf('4', '5', '6'), listOf('7', '8', '9'), listOf('*', '0', '#'))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    rows.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            row.forEach { k ->
                                DialKey(
                                    key = k,
                                    size = keySize,
                                    onTap = { press(k) },
                                    onLong = if (k == '0') ({ press('+') }) else null
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                if (showDual) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        sims.take(2).forEach { sim ->
                            Button(
                                onClick = { callWith(sim) },
                                modifier = Modifier.weight(1f).height(64.dp),
                                shape = RoundedCornerShape(32.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PulseColors.CallGreen, contentColor = androidx.compose.ui.graphics.Color.White)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null)
                                Column(Modifier.padding(start = 8.dp)) {
                                    Text(sim.label, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                    if (sim.carrierName.isNotBlank()) {
                                        Text(sim.carrierName, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(PulseColors.CallGreen)
                            .clickable(onClickLabel = "Call", role = Role.Button) { callWith(null) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Call", tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun DialKey(key: Char, size: Dp, onTap: () -> Unit, onLong: (() -> Unit)?) {
    var pressed by remember { mutableStateOf(false) }
    val tap by rememberUpdatedState(onTap)
    val long by rememberUpdatedState(onLong)
    val description = when (key) {
        '*' -> "star"
        '#' -> "hash"
        else -> key.toString()
    }
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (pressed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh)
            .semantics(mergeDescendants = true) {
                contentDescription = description
                role = Role.Button
                onClick(label = "Press") { tap(); true }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { tap() },
                    onLongPress = { long?.invoke() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(key.toString(), fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.Medium)
            val sub = if (key == '0') "+" else T9.lettersFor(key)
            if (sub.isNotEmpty()) {
                Text(sub, fontSize = 10.sp, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Tap deletes one digit; press-and-hold keeps deleting until the number is gone. */
@Composable
private fun BackspaceKey(onDelete: () -> Unit, modifier: Modifier = Modifier) {
    val delete by rememberUpdatedState(onDelete)
    val scope = rememberCoroutineScope()
    Box(
        modifier.size(52.dp).clip(CircleShape)
            .semantics(mergeDescendants = true) {
                contentDescription = "Delete digit"
                role = Role.Button
                onClick(label = "Delete") { delete(); true }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        delete()
                        val job = scope.launch {
                            delay(450)
                            while (true) {
                                delete()
                                delay(80)
                            }
                        }
                        tryAwaitRelease()
                        job.cancel()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.Backspace, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
