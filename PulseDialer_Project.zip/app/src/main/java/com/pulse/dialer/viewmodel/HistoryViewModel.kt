package com.pulse.dialer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pulse.dialer.container
import com.pulse.dialer.data.BlockedNumberEntity
import com.pulse.dialer.data.CallNoteEntity
import com.pulse.dialer.data.model.CallEntry
import com.pulse.dialer.data.model.CallKind
import com.pulse.dialer.data.model.Contact
import com.pulse.dialer.data.model.RecentItem
import com.pulse.dialer.util.PhoneUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class CallFilter(val label: String) {
    All("All"), Incoming("Incoming"), Outgoing("Outgoing"), Missed("Missed"), Rejected("Rejected")
}

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModel(app: Application) : AndroidViewModel(app) {
    private val c = app.container
    private val tick = MutableStateFlow(0)
    private val _filter = MutableStateFlow(CallFilter.All)
    val filter: StateFlow<CallFilter> = _filter.asStateFlow()
    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val log = tick.flatMapLatest { c.callLog.observe() }
    private val contactList = tick.flatMapLatest { c.contacts.observe() }
    private val notes = c.notes.observeAll()

    val notesByCall: StateFlow<Map<Long, String>> = notes
        .map { list -> list.associate { it.callLogId to it.note } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    val all: StateFlow<List<RecentItem>> = combine(log, contactList, notes) { entries, contacts, noteList ->
        val index = HashMap<String, Contact>()
        contacts.forEach { ct -> ct.phones.forEach { index.putIfAbsent(PhoneUtils.matchKey(it.number), ct) } }
        val noted = noteList.map { it.callLogId }.toHashSet()
        entries.map { e ->
            val key = PhoneUtils.matchKey(e.number)
            RecentItem(e, if (key.isEmpty()) null else index[key], e.id in noted)
        }
    }.onEach { _loading.value = false }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val visible: StateFlow<List<RecentItem>> = combine(all, _filter) { items, f ->
        when (f) {
            CallFilter.All -> items
            CallFilter.Incoming -> items.filter { it.entry.kind == CallKind.Incoming }
            CallFilter.Outgoing -> items.filter { it.entry.kind == CallKind.Outgoing }
            CallFilter.Missed -> items.filter { it.entry.kind == CallKind.Missed }
            CallFilter.Rejected -> items.filter { it.entry.kind == CallKind.Rejected || it.entry.kind == CallKind.Blocked }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val blocked: StateFlow<List<BlockedNumberEntity>> = c.blocked.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun refresh() {
        tick.value += 1
    }

    fun setFilter(f: CallFilter) {
        _filter.value = f
    }

    fun deleteEntry(entry: CallEntry, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = c.callLog.delete(entry.id)
            if (ok) c.notes.delete(entry.id)
            onDone(ok)
        }
    }

    fun clearHistory(onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val ok = c.callLog.clear()
            if (ok) c.notes.clear()
            onDone(ok)
        }
    }

    fun saveNote(entry: CallEntry, text: String) {
        viewModelScope.launch {
            if (text.isBlank()) c.notes.delete(entry.id)
            else c.notes.put(CallNoteEntity(entry.id, entry.number, text.trim(), System.currentTimeMillis()))
        }
    }

    fun block(number: String, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(c.blocked.block(number)) }
    }

    fun unblock(number: String) {
        viewModelScope.launch { c.blocked.unblock(number) }
    }

    fun lastOutgoing(onResult: (String?) -> Unit) {
        viewModelScope.launch { onResult(withContext(Dispatchers.IO) { c.callLog.lastOutgoing() }) }
    }
}
