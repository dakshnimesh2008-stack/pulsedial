package com.pulse.dialer.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pulse.dialer.call.CallManager
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.ui.components.rememberCorePermissionRequester
import com.pulse.dialer.ui.components.rememberPerms
import com.pulse.dialer.ui.screens.BlockedScreen
import com.pulse.dialer.ui.screens.CallDetailsScreen
import com.pulse.dialer.ui.screens.ContactDetailScreen
import com.pulse.dialer.ui.screens.ContactEditScreen
import com.pulse.dialer.ui.screens.ContactsScreen
import com.pulse.dialer.ui.screens.FavouritesScreen
import com.pulse.dialer.ui.screens.KeypadScreen
import com.pulse.dialer.ui.screens.RecentsScreen
import com.pulse.dialer.ui.screens.RecordingsScreen
import com.pulse.dialer.ui.screens.SettingsScreen
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.viewmodel.ContactsViewModel
import com.pulse.dialer.viewmodel.HistoryViewModel
import com.pulse.dialer.viewmodel.SettingsViewModel

object Routes {
    const val FAVOURITES = "favourites"
    const val RECENTS = "recents"
    const val KEYPAD = "keypad"
    const val CONTACTS = "contacts"
    const val SETTINGS = "settings"
    const val RECORDINGS = "recordings"
    const val BLOCKED = "blocked"
    const val CONTACT = "contact/{id}"
    const val EDIT = "edit?contactId={contactId}&number={number}"
    const val CALL = "call/{id}"

    fun contact(id: Long) = "contact/$id"
    fun edit(contactId: Long = -1L, number: String = "") = "edit?contactId=$contactId&number=${Uri.encode(number)}"
    fun call(id: Long) = "call/$id"
}

private class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem(Routes.FAVOURITES, "Favourites", Icons.Default.Star),
    TabItem(Routes.RECENTS, "Recents", Icons.Default.History),
    TabItem(Routes.KEYPAD, "Keypad", Icons.Default.Dialpad),
    TabItem(Routes.CONTACTS, "Contacts", Icons.Default.Contacts)
)

private fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun PulseNavHost(
    settings: AppSettings,
    dialNumber: String?,
    onDialConsumed: () -> Unit,
    routeRequest: String?,
    onRouteConsumed: () -> Unit
) {
    val nav = rememberNavController()
    val context = LocalContext.current
    val contactsVm: ContactsViewModel = viewModel()
    val historyVm: HistoryViewModel = viewModel()
    val settingsVm: SettingsViewModel = viewModel()
    val perms = rememberPerms()
    val requestPerms = rememberCorePermissionRequester()
    val sims by settingsVm.sims.collectAsStateWithLifecycle()
    val calls by CallManager.calls.collectAsStateWithLifecycle()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showTabs = tabs.any { it.route == route }

    LaunchedEffect(perms.contacts, perms.callLog) {
        contactsVm.refresh()
        historyVm.refresh()
    }
    LaunchedEffect(perms.phone) { settingsVm.refreshSims() }
    LaunchedEffect(dialNumber) {
        if (dialNumber != null) nav.goTab(Routes.KEYPAD)
    }
    LaunchedEffect(routeRequest) {
        if (routeRequest != null) {
            if (tabs.any { it.route == routeRequest }) nav.goTab(routeRequest)
            onRouteConsumed()
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            Column {
                if (calls.isNotEmpty()) {
                    val primary = calls.first()
                    Row(
                        Modifier.fillMaxWidth()
                            .background(PulseColors.CallGreen)
                            .clickable { CallManager.openCallScreen(context) }
                            .then(if (showTabs) Modifier else Modifier.navigationBarsPadding())
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(10.dp))
                        Text(
                            "Tap to return to call · ${primary.name ?: primary.number.ifBlank { "Private number" }}",
                            color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
                if (showTabs) {
                    NavigationBar {
                        tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = route == tab.route,
                                onClick = { if (route != tab.route) nav.goTab(tab.route) },
                                icon = { Icon(tab.icon, contentDescription = null) },
                                label = { Text(tab.label) }
                            )
                        }
                    }
                }
            }
        }
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Routes.KEYPAD,
            modifier = Modifier.fillMaxSize().padding(inner)
        ) {
            composable(Routes.FAVOURITES) {
                FavouritesScreen(
                    vm = contactsVm, perms = perms, onRequestPerms = requestPerms,
                    onOpenContact = { nav.navigate(Routes.contact(it)) },
                    onBrowseContacts = { nav.goTab(Routes.CONTACTS) },
                    onSettings = { nav.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.RECENTS) {
                RecentsScreen(
                    vm = historyVm, perms = perms, onRequestPerms = requestPerms,
                    onOpenCall = { nav.navigate(Routes.call(it)) },
                    onSettings = { nav.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.KEYPAD) {
                KeypadScreen(
                    prefill = dialNumber,
                    onPrefillConsumed = onDialConsumed,
                    settings = settings,
                    sims = sims,
                    contactsVm = contactsVm,
                    historyVm = historyVm,
                    onSettings = { nav.navigate(Routes.SETTINGS) },
                    onAddContact = { nav.navigate(Routes.edit(number = it)) },
                    onOpenContact = { nav.navigate(Routes.contact(it)) }
                )
            }
            composable(Routes.CONTACTS) {
                ContactsScreen(
                    vm = contactsVm, perms = perms, onRequestPerms = requestPerms,
                    onOpenContact = { nav.navigate(Routes.contact(it)) },
                    onAdd = { nav.navigate(Routes.edit()) },
                    onSettings = { nav.navigate(Routes.SETTINGS) }
                )
            }
            composable(Routes.CONTACT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                ContactDetailScreen(
                    id = entry.arguments?.getLong("id") ?: -1L,
                    vm = contactsVm,
                    onBack = { nav.popBackStack() },
                    onEdit = { nav.navigate(Routes.edit(contactId = it)) }
                )
            }
            composable(
                Routes.EDIT,
                arguments = listOf(
                    navArgument("contactId") { type = NavType.LongType; defaultValue = -1L },
                    navArgument("number") { type = NavType.StringType; defaultValue = "" }
                )
            ) { entry ->
                ContactEditScreen(
                    contactId = entry.arguments?.getLong("contactId") ?: -1L,
                    prefillNumber = entry.arguments?.getString("number").orEmpty(),
                    vm = contactsVm,
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.CALL, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                CallDetailsScreen(
                    callId = entry.arguments?.getLong("id") ?: -1L,
                    vm = historyVm,
                    onBack = { nav.popBackStack() },
                    onOpenCall = { nav.navigate(Routes.call(it)) },
                    onOpenContact = { nav.navigate(Routes.contact(it)) },
                    onSaveContact = { nav.navigate(Routes.edit(number = it)) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    vm = settingsVm,
                    onBack = { nav.popBackStack() },
                    onOpenRecordings = { nav.navigate(Routes.RECORDINGS) },
                    onOpenBlocked = { nav.navigate(Routes.BLOCKED) }
                )
            }
            composable(Routes.RECORDINGS) { RecordingsScreen(vm = settingsVm, onBack = { nav.popBackStack() }) }
            composable(Routes.BLOCKED) { BlockedScreen(vm = historyVm, onBack = { nav.popBackStack() }) }
        }
    }
}
