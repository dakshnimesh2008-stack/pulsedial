package com.pulse.dialer.call

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

/** The component Android Telecom binds to for every call once Pulse is the default Phone app. */
class PulseInCallService : InCallService() {
    override fun onCreate() {
        super.onCreate()
        CallManager.attach(this)
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.onCallAdded(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.onCallRemoved(call)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.onAudioState(audioState)
    }

    override fun onBringToForeground(showDialpad: Boolean) {
        super.onBringToForeground(showDialpad)
        CallNotifications.startInCallUi(this)
    }

    override fun onDestroy() {
        CallManager.detach()
        super.onDestroy()
    }
}
