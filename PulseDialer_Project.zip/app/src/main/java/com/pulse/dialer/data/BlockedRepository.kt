package com.pulse.dialer.data

import android.content.ContentValues
import android.content.Context
import android.provider.BlockedNumberContract
import com.pulse.dialer.util.PhoneUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

/**
 * Local block list. When Pulse is the default phone app the number is also added to Android's own block list
 * (so the system stops the call before it rings); if Android refuses, the local list still rejects the call.
 */
class BlockedRepository(private val context: Context, private val dao: BlockedDao) {
    fun observeAll(): Flow<List<BlockedNumberEntity>> = dao.observeAll()

    suspend fun isBlocked(number: String): Boolean {
        val key = PhoneUtils.matchKey(number)
        return key.isNotEmpty() && dao.get(key) != null
    }

    suspend fun block(number: String): Boolean {
        val key = PhoneUtils.matchKey(number)
        if (key.isEmpty()) return false
        dao.put(BlockedNumberEntity(key, number, System.currentTimeMillis()))
        withContext(Dispatchers.IO) {
            try {
                if (BlockedNumberContract.canCurrentUserBlockNumbers(context)) {
                    val values = ContentValues().apply {
                        put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number)
                    }
                    context.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, values)
                }
            } catch (e: Exception) {
                // System block list not available to this app right now; the local list still applies.
            }
        }
        return true
    }

    suspend fun unblock(number: String) {
        val key = PhoneUtils.matchKey(number)
        if (key.isEmpty()) return
        dao.delete(key)
        withContext(Dispatchers.IO) {
            try {
                if (BlockedNumberContract.canCurrentUserBlockNumbers(context)) {
                    BlockedNumberContract.unblock(context, number)
                }
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    suspend fun clear() = dao.clear()
}
