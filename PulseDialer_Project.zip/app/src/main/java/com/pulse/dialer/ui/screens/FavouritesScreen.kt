package com.pulse.dialer.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.data.model.FavouriteItem
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.LocalDial
import com.pulse.dialer.ui.components.TabScaffold
import com.pulse.dialer.ui.components.sendSms
import com.pulse.dialer.util.Perms
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.viewmodel.ContactsViewModel

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FavouritesScreen(
    vm: ContactsViewModel,
    perms: Perms,
    onRequestPerms: () -> Unit,
    onOpenContact: (Long) -> Unit,
    onBrowseContacts: () -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val dial = LocalDial.current
    val favourites by vm.favourites.collectAsStateWithLifecycle()
    var menuFor by remember { mutableStateOf<FavouriteItem?>(null) }
    var pickNumberFor by remember { mutableStateOf<FavouriteItem?>(null) }
    var photoFor by remember { mutableStateOf<FavouriteItem?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val target = photoFor
        photoFor = null
        if (uri != null && target != null) vm.setCustomPhoto(target, uri)
    }

    TabScaffold(title = "Favourites", onSettings = onSettings) {
        if (!perms.contacts) {
            EmptyState(Icons.Default.Star, "Contacts access is off", "Allow access to see and call your favourite contacts.", "Allow access", onRequestPerms)
            return@TabScaffold
        }
        if (favourites.isEmpty()) {
            EmptyState(
                Icons.Default.Star, "No favourites yet",
                "Open a contact and tap the star to add them here for one-tap calling.",
                "Browse contacts", onBrowseContacts
            )
            return@TabScaffold
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(favourites, key = { it.contact.id }) { fav ->
                Column(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .combinedClickable(
                            onClick = {
                                if (fav.contact.phones.size > 1) pickNumberFor = fav
                                else fav.contact.primaryNumber?.let { dial?.dial(it) }
                            },
                            onLongClick = { menuFor = fav },
                            onClickLabel = "Call ${fav.contact.name}",
                            onLongClickLabel = "More actions"
                        )
                        .padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ContactAvatar(fav.contact.name, fav.photo, 84.dp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        fav.contact.name,
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    pickNumberFor?.let { fav ->
        AlertDialog(
            onDismissRequest = { pickNumberFor = null },
            title = { Text("Call ${fav.contact.name}") },
            text = {
                Column {
                    fav.contact.phones.forEach { p ->
                        Text(
                            PhoneUtils.format(p.number),
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.fillMaxWidth()
                                .clickable {
                                    pickNumberFor = null
                                    dial?.dial(p.number)
                                }
                                .padding(vertical = 14.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pickNumberFor = null }) { Text("Cancel") } }
        )
    }

    menuFor?.let { fav ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(fav.contact.name) },
            text = {
                Column {
                    @Composable
                    fun Item(label: String, action: () -> Unit) {
                        TextButton(onClick = { menuFor = null; action() }, modifier = Modifier.fillMaxWidth()) {
                            Text(label, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
                        }
                    }
                    Item("Message") { fav.contact.primaryNumber?.let { sendSms(context, it) } }
                    Item("Contact details") { onOpenContact(fav.contact.id) }
                    Item("Choose a custom photo") {
                        photoFor = fav
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                    if (fav.customPhotoUri != null) Item("Use contact photo again") { vm.clearCustomPhoto(fav) }
                    Item("Move earlier") { vm.moveFavourite(fav, -1) }
                    Item("Move later") { vm.moveFavourite(fav, 1) }
                    Item("Remove from favourites") { vm.toggleFavourite(fav.contact) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text("Close") } }
        )
    }
}
