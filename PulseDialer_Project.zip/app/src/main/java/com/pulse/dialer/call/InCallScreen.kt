package com.pulse.dialer.call

import android.telecom.CallAudioState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.SwapCalls
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.content.Intent
import com.pulse.dialer.MainActivity
import com.pulse.dialer.container
import com.pulse.dialer.data.AppSettings
import com.pulse.dialer.recording.RecordingController
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.Pill
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.T9
import com.pulse.dialer.util.TimeUtils
import kotlinx.coroutines.delay

@Composable
fun InCallScreen(onFinish: () -> Unit) {
    val context = LocalContext.current
    val calls by CallManager.calls.collectAsStateWithLifecycle()
    val audio by CallManager.audio.collectAsStateWithLifecycle()
    val rec by RecordingController.state.collectAsStateWithLifecycle()
    val ended by CallManager.lastEnded.collectAsStateWithLifecycle()
    val settings by context.container.settings.settings.collectAsStateWithLifecycle(AppSettings())
    var showKeypad by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }

    LaunchedEffect(calls.isEmpty()) {
        if (calls.isEmpty()) {
            delay(1300)
            onFinish()
        }
    }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(500)
        }
    }

    val primary = calls.firstOrNull()
    val other = calls.getOrNull(1)
    val ringing = primary?.state == CallUiState.Ringing

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0B1E3D), Color(0xFF050A14))))
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(listOf(Color(0x334DD8FF), Color.Transparent), radius = 900f)
            )
        )
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status chips: SIM and recording indicator
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.height(30.dp)) {
                primary?.simLabel?.let { Pill(it, PulseColors.Cyan) }
                when (rec.phase) {
                    RecordingController.Phase.Recording -> Pill("● REC", PulseColors.EndRed)
                    RecordingController.Phase.Unavailable -> if (primary != null) Pill("Not recorded", PulseColors.Amber)
                    RecordingController.Phase.Idle -> {}
                }
            }
            if (rec.phase == RecordingController.Phase.Unavailable && primary != null && rec.message != null) {
                Text(
                    rec.message ?: "",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(Modifier.weight(1f))

            val name = primary?.name ?: ended?.name
            val number = primary?.number ?: ended?.number.orEmpty()
            val title = when {
                primary?.isConference == true -> "Conference call"
                name != null -> name
                number.isNotBlank() -> PhoneUtils.format(number)
                else -> "Private number"
            }
            PulsingAvatar(name = name ?: "", photoUri = primary?.photoUri ?: ended?.photoUri, pulsing = ringing)
            Spacer(Modifier.height(12.dp))
            Text(
                title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
            if (name != null && number.isNotBlank() && primary?.isConference != true) {
                Text(PhoneUtils.format(number), color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
            }
            Spacer(Modifier.height(8.dp))
            if (primary?.isUnknown == true) Pill("Unknown caller", PulseColors.Amber)
            Spacer(Modifier.height(8.dp))
            Text(
                text = when {
                    primary == null -> ended?.let { if (it.durationSeconds > 0) "Call ended · ${TimeUtils.clock(it.durationSeconds)}" else "Call ended" } ?: "Call ended"
                    primary.state == CallUiState.Ringing -> if (primary.isIncoming && other != null) "Incoming call · answering holds your current call" else "Incoming call"
                    primary.state == CallUiState.Dialing -> "Calling…"
                    primary.state == CallUiState.Connecting -> "Connecting…"
                    primary.state == CallUiState.Holding -> "On hold"
                    primary.state == CallUiState.Disconnecting -> "Ending call…"
                    else -> {
                        val secs = if (primary.connectTimeMillis > 0) (now - primary.connectTimeMillis) / 1000 else 0
                        val base = TimeUtils.clock(secs)
                        if (primary.isConference) "$base · ${primary.conferenceSize} people" else base
                    }
                },
                color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp
            )

            Spacer(Modifier.weight(1f))

            if (primary != null) {
                if (ringing) {
                    RingingControls(
                        isUnknown = primary.isUnknown && primary.number.isNotBlank(),
                        onDecline = { CallManager.rejectRinging() },
                        onAnswer = { CallManager.answerRinging() },
                        onBlock = { CallManager.rejectAndBlock() }
                    )
                } else {
                    if (other != null) {
                        OtherCallBanner(other)
                    }
                    if (showKeypad) {
                        InCallKeypad(
                            typed = typed,
                            onKey = { c ->
                                typed += c
                                CallManager.dtmf(c)
                            },
                            onHide = { showKeypad = false }
                        )
                    } else {
                        ControlGrid(
                            primary = primary, other = other, audio = audio, settings = settings,
                            recording = rec.phase == RecordingController.Phase.Recording,
                            onKeypad = { showKeypad = true }
                        )
                    }
                    Spacer(Modifier.height(20.dp))
                    RoundButton(PulseColors.EndRed, Icons.Default.CallEnd, "End call", 72) { CallManager.hangup(primary.key) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PulsingAvatar(name: String, photoUri: String?, pulsing: Boolean) {
    val transition = rememberInfiniteTransition(label = "ring")
    val scale by transition.animateFloat(
        initialValue = 1f, targetValue = 1.45f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "scale"
    )
    val alpha by transition.animateFloat(
        initialValue = 0.4f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart), label = "alpha"
    )
    Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        if (pulsing) {
            Box(Modifier.size(140.dp).scale(scale).background(PulseColors.Cyan.copy(alpha = alpha), CircleShape))
        }
        ContactAvatar(name, photoUri, 140.dp)
    }
}

@Composable
private fun RoundButton(color: Color, icon: ImageVector, description: String, size: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(color)
            .clickable(onClickLabel = description, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = Color.White, modifier = Modifier.size((size * 0.45f).dp))
    }
}

@Composable
private fun RingingControls(isUnknown: Boolean, onDecline: () -> Unit, onAnswer: () -> Unit, onBlock: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "answer")
    val pulse by transition.animateFloat(
        initialValue = 1f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "pulse"
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            RoundButton(PulseColors.EndRed, Icons.Default.CallEnd, "Decline call", 78, onDecline)
            Spacer(Modifier.height(6.dp))
            Text("Decline", color = Color.White.copy(alpha = 0.85f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.scale(pulse)) { RoundButton(PulseColors.CallGreen, Icons.Default.Call, "Answer call", 78, onAnswer) }
            Spacer(Modifier.height(6.dp))
            Text("Answer", color = Color.White.copy(alpha = 0.85f))
        }
    }
    if (isUnknown) {
        TextButton(onClick = onBlock, modifier = Modifier.padding(top = 12.dp)) {
            Text("Decline and block this number", color = Color.White.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun OtherCallBanner(other: CallInfo) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.1f)).padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                other.name ?: PhoneUtils.format(other.number).ifBlank { "Private number" },
                color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (other.state == CallUiState.Holding) "On hold" else "Active",
                color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp
            )
        }
        TextButton(onClick = { CallManager.swap() }) { Text("Swap", color = PulseColors.Cyan) }
        if (other.canMerge) TextButton(onClick = { CallManager.merge() }) { Text("Merge", color = PulseColors.Cyan) }
    }
}

@Composable
private fun ControlGrid(
    primary: CallInfo,
    other: CallInfo?,
    audio: AudioInfo,
    settings: AppSettings,
    recording: Boolean,
    onKeypad: () -> Unit
) {
    val context = LocalContext.current
    var routeMenu by remember { mutableStateOf(false) }
    val multiRoute = audio.hasBluetooth || audio.hasWired
    val held = primary.state == CallUiState.Holding

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ControlButton(
                if (audio.muted) Icons.Default.MicOff else Icons.Default.Mic,
                if (audio.muted) "Unmute" else "Mute", audio.muted
            ) { CallManager.toggleMute() }
            ControlButton(Icons.Default.Dialpad, "Keypad", false, onClick = onKeypad)
            Box {
                ControlButton(
                    if (audio.hasBluetooth && audio.route == CallAudioState.ROUTE_BLUETOOTH) Icons.Default.Bluetooth else Icons.Default.VolumeUp,
                    if (multiRoute) "Audio" else "Speaker",
                    audio.speakerOn || audio.route == CallAudioState.ROUTE_BLUETOOTH
                ) {
                    if (multiRoute) routeMenu = true
                    else CallManager.setRoute(if (audio.speakerOn) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                }
                DropdownMenu(expanded = routeMenu, onDismissRequest = { routeMenu = false }) {
                    DropdownMenuItem(text = { Text("Phone") }, onClick = { routeMenu = false; CallManager.setRoute(CallAudioState.ROUTE_EARPIECE) })
                    DropdownMenuItem(text = { Text("Speaker") }, onClick = { routeMenu = false; CallManager.setRoute(CallAudioState.ROUTE_SPEAKER) })
                    if (audio.hasBluetooth) {
                        DropdownMenuItem(text = { Text("Bluetooth") }, onClick = { routeMenu = false; CallManager.setRoute(CallAudioState.ROUTE_BLUETOOTH) })
                    }
                    if (audio.hasWired) {
                        DropdownMenuItem(text = { Text("Wired headset") }, onClick = { routeMenu = false; CallManager.setRoute(CallAudioState.ROUTE_WIRED_HEADSET) })
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ControlButton(Icons.Default.PersonAdd, "Add call", false, enabled = CallManager.canAddCall) {
                context.startActivity(
                    Intent(context, MainActivity::class.java)
                        .setAction(Intent.ACTION_DIAL)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                )
            }
            if (other != null) {
                ControlButton(Icons.Default.SwapCalls, "Swap", false) { CallManager.swap() }
            } else {
                ControlButton(Icons.Default.Pause, if (held) "Resume" else "Hold", held, enabled = primary.canHold) {
                    CallManager.toggleHold(primary.key)
                }
            }
            if (settings.recordingEnabled) {
                ControlButton(Icons.Default.FiberManualRecord, if (recording) "Stop rec" else "Record", recording) {
                    CallManager.toggleRecording()
                }
            } else if (primary.canMerge) {
                ControlButton(Icons.Default.CallMerge, "Merge", false) { CallManager.merge() }
            } else {
                Spacer(Modifier.size(64.dp))
            }
        }
    }
}

@Composable
private fun ControlButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 4.dp)) {
        Box(
            Modifier.size(64.dp).clip(CircleShape)
                .background(if (active) Color.White else Color.White.copy(alpha = 0.12f))
                .clickable(enabled = enabled, onClickLabel = label, role = Role.Button, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon, contentDescription = label,
                tint = if (active) Color(0xFF0B1E3D) else Color.White.copy(alpha = if (enabled) 1f else 0.35f),
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White.copy(alpha = if (enabled) 0.85f else 0.4f), fontSize = 12.sp)
    }
}

@Composable
private fun InCallKeypad(typed: String, onKey: (Char) -> Unit, onHide: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            typed.takeLast(20).ifEmpty { " " },
            color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light, maxLines = 1,
            modifier = Modifier.height(36.dp)
        )
        val rows = listOf(listOf('1', '2', '3'), listOf('4', '5', '6'), listOf('7', '8', '9'), listOf('*', '0', '#'))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    row.forEach { k ->
                        Box(
                            Modifier.size(62.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f))
                                .clickable(onClickLabel = "Send $k", role = Role.Button) { onKey(k) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(k.toString(), color = Color.White, fontSize = 24.sp)
                                val sub = if (k == '0') "+" else T9.lettersFor(k)
                                if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.6f), fontSize = 9.sp)
                            }
                        }
                    }
                }
            }
        }
        TextButton(onClick = onHide) { Text("Hide keypad", color = PulseColors.Cyan) }
    }
}
