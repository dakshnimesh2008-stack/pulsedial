package com.pulse.dialer.data.model

import android.telecom.PhoneAccountHandle

data class PhoneEntry(val dataId: Long, val number: String, val type: Int, val label: String?)

data class Contact(
    val id: Long,
    val lookupKey: String,
    val name: String,
    val photoUri: String?,
    val starred: Boolean,
    val phones: List<PhoneEntry>
) {
    val primaryNumber: String? get() = phones.firstOrNull()?.number
}

data class ContactMatch(val name: String, val photoUri: String?, val lookupKey: String?)

data class FavouriteItem(val contact: Contact, val customPhotoUri: String?, val sortIndex: Int) {
    val photo: String? get() = customPhotoUri ?: contact.photoUri
}

data class SimInfo(
    val slotIndex: Int,
    val subscriptionId: Int,
    val carrierName: String,
    val handle: PhoneAccountHandle?
) {
    val label: String get() = "SIM ${slotIndex + 1}"
    val fullLabel: String get() = if (carrierName.isBlank()) label else "$label · $carrierName"
}

enum class CallKind { Incoming, Outgoing, Missed, Rejected, Blocked, Voicemail, Other }

data class CallEntry(
    val id: Long,
    val number: String,
    val cachedName: String?,
    val kind: CallKind,
    val dateMillis: Long,
    val durationSec: Long,
    val simLabel: String?
)

data class RecentItem(val entry: CallEntry, val contact: Contact?, val hasNote: Boolean) {
    val isPrivate: Boolean get() = entry.number.isBlank()
    val isUnknown: Boolean get() = contact == null && !isPrivate
    val displayName: String?
        get() = contact?.name ?: entry.cachedName?.takeIf { it.isNotBlank() }
}
