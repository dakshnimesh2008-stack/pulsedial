package com.pulse.dialer

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.ui.PulseRoot
import com.pulse.dialer.ui.theme.PulseTheme
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    private val dialNumber = mutableStateOf<String?>(null)
    private val routeRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        // One quick local read so the first frame already uses the saved theme.
        val initial = runBlocking { container.settings.current() }
        setContent {
            val settings by container.settings.settings.collectAsStateWithLifecycle(initial)
            PulseTheme(themeMode = settings.theme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    PulseRoot(
                        settings = settings,
                        dialNumber = dialNumber.value,
                        onDialConsumed = { dialNumber.value = null },
                        routeRequest = routeRequest.value,
                        onRouteConsumed = { routeRequest.value = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** tel: links and the system "dial" action prefill the keypad. */
    private fun handleIntent(i: Intent?) {
        val uri = i?.data
        if (uri != null && uri.scheme == "tel") {
            dialNumber.value = uri.schemeSpecificPart
        } else if (i?.action == Intent.ACTION_DIAL) {
            dialNumber.value = ""
        }
        i?.getStringExtra(EXTRA_ROUTE)?.let { routeRequest.value = it }
    }

    companion object {
        const val EXTRA_ROUTE = "route"
    }
}
