package com.pulse.dialer.data

import android.content.Context

/** Simple manual dependency container. Everything is created lazily and stays on the device. */
class AppContainer(private val context: Context) {
    val db: AppDatabase by lazy { AppDatabase.build(context) }
    val settings: SettingsRepository by lazy { SettingsRepository(context) }
    val sims: SimRepository by lazy { SimRepository(context) }
    val contacts: ContactsRepository by lazy { ContactsRepository(context) }
    val callLog: CallLogRepository by lazy { CallLogRepository(context, sims) }
    val blocked: BlockedRepository by lazy { BlockedRepository(context, db.blocked()) }
    val favourites: FavouritesRepository by lazy { FavouritesRepository(context, db.favourites()) }
    val recordings: RecordingRepository by lazy { RecordingRepository(context, db.recordings()) }
    val notes: CallNoteDao get() = db.callNotes()
}
