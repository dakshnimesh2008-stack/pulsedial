package com.pulse.dialer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.data.model.CallKind
import com.pulse.dialer.data.model.RecentItem
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.LocalDial
import com.pulse.dialer.ui.components.Pill
import com.pulse.dialer.ui.components.TabScaffold
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.Perms
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.TimeUtils
import com.pulse.dialer.viewmodel.CallFilter
import com.pulse.dialer.viewmodel.HistoryViewModel

fun kindIcon(kind: CallKind): ImageVector = when (kind) {
    CallKind.Incoming -> Icons.Default.CallReceived
    CallKind.Outgoing -> Icons.Default.CallMade
    CallKind.Missed -> Icons.Default.CallMissed
    CallKind.Rejected, CallKind.Blocked -> Icons.Default.Block
    CallKind.Voicemail -> Icons.Default.Voicemail
    CallKind.Other -> Icons.Default.Call
}

fun kindLabel(kind: CallKind): String = when (kind) {
    CallKind.Incoming -> "Incoming"
    CallKind.Outgoing -> "Outgoing"
    CallKind.Missed -> "Missed"
    CallKind.Rejected -> "Rejected"
    CallKind.Blocked -> "Blocked"
    CallKind.Voicemail -> "Voicemail"
    CallKind.Other -> "Call"
}

private sealed interface RecentRow {
    data class Header(val label: String) : RecentRow
    data class Entry(val item: RecentItem) : RecentRow
}

@Composable
fun RecentsScreen(
    vm: HistoryViewModel,
    perms: Perms,
    onRequestPerms: () -> Unit,
    onOpenCall: (Long) -> Unit,
    onSettings: () -> Unit
) {
    val context = LocalContext.current
    val dial = LocalDial.current
    val items by vm.visible.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    TabScaffold(
        title = "Recents",
        onSettings = onSettings,
        actions = {
            if (perms.callLog && items.isNotEmpty() && filter == CallFilter.All) {
                IconButton(onClick = { confirmClear = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "Clear call history")
                }
            }
        }
    ) {
        if (!perms.callLog) {
            EmptyState(
                Icons.Default.History, "Call history access is off",
                "Pulse shows the call log that Android already keeps on your phone.",
                "Allow access", onRequestPerms
            )
            return@TabScaffold
        }
        Column(Modifier.fillMaxSize()) {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                items(CallFilter.values().toList()) { f ->
                    FilterChip(selected = filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) })
                }
            }
            val rows = remember(items) {
                val out = ArrayList<RecentRow>()
                var lastDay = ""
                items.forEach { item ->
                    val day = TimeUtils.dayLabel(context, item.entry.dateMillis)
                    if (day != lastDay) {
                        out.add(RecentRow.Header(day))
                        lastDay = day
                    }
                    out.add(RecentRow.Entry(item))
                }
                out
            }
            when {
                loading && items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                rows.isEmpty() -> EmptyState(
                    Icons.Default.History,
                    if (filter == CallFilter.All) "No calls yet" else "No ${filter.label.lowercase()} calls",
                    "Your calls will appear here."
                )
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)) {
                    items(
                        rows,
                        key = { r ->
                            when (r) {
                                is RecentRow.Header -> "h_${r.label}"
                                is RecentRow.Entry -> "e_${r.item.entry.id}"
                            }
                        }
                    ) { r ->
                        when (r) {
                            is RecentRow.Header -> Text(
                                r.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                            )
                            is RecentRow.Entry -> RecentRowItem(
                                r.item,
                                onClick = { onOpenCall(r.item.entry.id) },
                                onCall = { dial?.dial(r.item.entry.number) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear call history?") },
            text = { Text("This deletes the call log on your phone, including any notes you added. It can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    vm.clearHistory { ok ->
                        if (!ok) android.widget.Toast.makeText(context, "Android did not allow clearing the call log", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun RecentRowItem(item: RecentItem, onClick: () -> Unit, onCall: () -> Unit) {
    val context = LocalContext.current
    val e = item.entry
    val missed = e.kind == CallKind.Missed
    val title = item.displayName ?: PhoneUtils.format(e.number).ifBlank { "Private number" }
    val tint = if (missed) PulseColors.EndRed else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ContactAvatar(item.displayName ?: "", item.contact?.photoUri, 46.dp)
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                color = if (missed) PulseColors.EndRed else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(kindIcon(e.kind), contentDescription = kindLabel(e.kind), tint = tint, modifier = Modifier.size(15.dp))
                Spacer(Modifier.size(4.dp))
                val parts = buildList {
                    add(TimeUtils.time(context, e.dateMillis))
                    if (e.durationSec > 0) add(TimeUtils.spoken(e.durationSec))
                    e.simLabel?.let { add(it) }
                }
                Text(
                    parts.joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                if (item.isUnknown) {
                    Spacer(Modifier.size(8.dp))
                    Pill("Unknown", PulseColors.Amber)
                }
                if (item.hasNote) {
                    Spacer(Modifier.size(6.dp))
                    Icon(Icons.Default.EditNote, contentDescription = "Has a note", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                }
            }
        }
        if (!item.isPrivate) {
            IconButton(onClick = onCall) {
                Icon(Icons.Default.Call, contentDescription = "Call back $title", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
