package com.pulse.dialer.ui.components

import android.Manifest
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pulse.dialer.call.CallLauncher
import com.pulse.dialer.container
import com.pulse.dialer.data.model.SimInfo
import com.pulse.dialer.util.Permissions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChooserRequest(val number: String, val sims: List<SimInfo>)

/**
 * Decides how a call is placed: checks the call permission, applies the user's SIM preference (and Android's
 * own default) and asks which SIM to use only when it really is ambiguous.
 */
class DialController(private val context: Context, private val scope: CoroutineScope) {
    var chooser by mutableStateOf<ChooserRequest?>(null)
    var requestCallPermission: ((String) -> Unit)? = null

    fun dial(number: String) {
        if (number.isBlank()) return
        scope.launch {
            if (!Permissions.granted(context, Manifest.permission.CALL_PHONE)) {
                requestCallPermission?.invoke(number)
                return@launch
            }
            val c = context.container
            val settings = c.settings.current()
            val sims = withContext(Dispatchers.IO) { c.sims.activeSims() }
            if (sims.size < 2) {
                place(number, sims.firstOrNull())
                return@launch
            }
            val pref = settings.defaultSim
            when {
                pref.startsWith("slot:") -> {
                    val slot = pref.removePrefix("slot:").toIntOrNull()
                    val sim = sims.firstOrNull { it.slotIndex == slot }
                    if (sim != null) place(number, sim) else chooser = ChooserRequest(number, sims)
                }
                pref == "ask" -> chooser = ChooserRequest(number, sims)
                else -> {
                    // "System default": follow Android's own choice, ask if Android is set to "ask every time".
                    if (c.sims.defaultOutgoingHandle() == null) chooser = ChooserRequest(number, sims) else place(number, null)
                }
            }
        }
    }

    /** Calls with an explicitly chosen SIM (used by the dual-SIM call buttons on the keypad). */
    fun dialWith(number: String, sim: SimInfo?) {
        if (number.isBlank()) return
        if (!Permissions.granted(context, Manifest.permission.CALL_PHONE)) {
            requestCallPermission?.invoke(number)
            return
        }
        place(number, sim)
    }

    fun place(number: String, sim: SimInfo?) {
        if (!CallLauncher.place(context, number, sim)) {
            Toast.makeText(context, "Could not place the call", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun DialHost(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = remember { DialController(context, scope) }
    var pending by remember { mutableStateOf<String?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val n = pending
        pending = null
        if (granted && n != null) controller.dial(n)
        else Toast.makeText(context, "Calling needs the Phone permission", Toast.LENGTH_SHORT).show()
    }
    controller.requestCallPermission = { number ->
        pending = number
        permissionLauncher.launch(Manifest.permission.CALL_PHONE)
    }

    CompositionLocalProvider(LocalDial provides controller) { content() }

    controller.chooser?.let { req ->
        AlertDialog(
            onDismissRequest = { controller.chooser = null },
            title = { Text("Call with which SIM?") },
            text = {
                Column {
                    req.sims.forEach { sim ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    controller.chooser = null
                                    controller.place(req.number, sim)
                                }
                                .padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.SimCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Column(Modifier.padding(start = 16.dp)) {
                                Text(sim.label, style = MaterialTheme.typography.titleMedium)
                                if (sim.carrierName.isNotBlank()) {
                                    Text(sim.carrierName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { controller.chooser = null }) { Text("Cancel") } }
        )
    }
}
