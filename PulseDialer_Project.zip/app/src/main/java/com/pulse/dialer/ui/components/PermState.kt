package com.pulse.dialer.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.pulse.dialer.util.DefaultDialer
import com.pulse.dialer.util.Perms
import com.pulse.dialer.util.Permissions

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Increments every time the screen resumes (e.g. after a permission dialog or Settings), to refresh checks. */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    return tick
}

@Composable
fun rememberPerms(): Perms {
    val tick = rememberResumeTick()
    val context = LocalContext.current
    return remember(tick) { Permissions.check(context) }
}

@Composable
fun rememberIsDefaultDialer(): Boolean {
    val tick = rememberResumeTick()
    val context = LocalContext.current
    return remember(tick) { DefaultDialer.isDefault(context) }
}

/** Returns a function that asks for all permissions the dialer needs; sends the user to Settings if they were blocked. */
@Composable
fun rememberCorePermissionRequester(): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val denied = result.filterValues { !it }.keys
        val activity = context.findActivity()
        if (denied.isNotEmpty() && activity != null &&
            denied.none { ActivityCompat.shouldShowRequestPermissionRationale(activity, it) }
        ) {
            Toast.makeText(context, "Allow the permissions in Settings › Permissions", Toast.LENGTH_LONG).show()
            context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)))
        }
    }
    return { launcher.launch(Permissions.coreRequest) }
}

@Composable
fun rememberDefaultDialerRequester(): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    return {
        val intent = DefaultDialer.requestIntent(context)
        if (intent != null) {
            try {
                launcher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Open Settings › Apps › Default apps › Phone app to choose Pulse", Toast.LENGTH_LONG).show()
            }
        } else if (DefaultDialer.isDefault(context)) {
            Toast.makeText(context, "Pulse is already your default phone app", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "This device does not offer a default phone app setting", Toast.LENGTH_LONG).show()
        }
    }
}
