package com.pulse.dialer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pulse.dialer.data.model.CallKind
import com.pulse.dialer.ui.components.ContactAvatar
import com.pulse.dialer.ui.components.EmptyState
import com.pulse.dialer.ui.components.LocalDial
import com.pulse.dialer.ui.components.Pill
import com.pulse.dialer.ui.components.SectionLabel
import com.pulse.dialer.ui.components.SubScreen
import com.pulse.dialer.ui.components.sendSms
import com.pulse.dialer.ui.theme.PulseColors
import com.pulse.dialer.util.PhoneUtils
import com.pulse.dialer.util.TimeUtils
import com.pulse.dialer.viewmodel.HistoryViewModel

@Composable
fun CallDetailsScreen(
    callId: Long,
    vm: HistoryViewModel,
    onBack: () -> Unit,
    onOpenCall: (Long) -> Unit,
    onOpenContact: (Long) -> Unit,
    onSaveContact: (String) -> Unit
) {
    val context = LocalContext.current
    val dial = LocalDial.current
    val all by vm.all.collectAsStateWithLifecycle()
    val blocked by vm.blocked.collectAsStateWithLifecycle()
    val item = all.firstOrNull { it.entry.id == callId }
    var confirmDelete by remember { mutableStateOf(false) }

    SubScreen(title = "Call details", onBack = onBack) { padding ->
        if (item == null) {
            Column(Modifier.fillMaxSize().padding(padding)) {
                EmptyState(Icons.Default.Person, "Call not found", "This entry may have been deleted.")
            }
            return@SubScreen
        }
        val e = item.entry
        val title = item.displayName ?: PhoneUtils.format(e.number).ifBlank { "Private number" }
        val isBlocked = blocked.any { PhoneUtils.sameNumber(it.number, e.number) }
        val savedNote = vm.notesByCall.collectAsStateWithLifecycle().value[e.id].orEmpty()
        var noteText by remember(e.id, savedNote) { mutableStateOf(savedNote) }
        val history = remember(all, e.number) {
            if (item.isPrivate) emptyList() else all.filter { PhoneUtils.sameNumber(it.entry.number, e.number) && it.entry.id != e.id }.take(15)
        }

        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                ContactAvatar(item.displayName ?: "", item.contact?.photoUri, 96.dp)
                Spacer(Modifier.height(12.dp))
                Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                if (item.displayName != null && e.number.isNotBlank()) {
                    Text(PhoneUtils.format(e.number), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (item.isUnknown) Pill("Unknown caller", PulseColors.Amber)
                    if (item.isPrivate) Pill("Private number", PulseColors.Amber)
                    if (isBlocked) Pill("Blocked", PulseColors.EndRed)
                    e.simLabel?.let { Pill(it, MaterialTheme.colorScheme.primary) }
                }
            }

            if (!item.isPrivate) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    QuickAction(Icons.Default.Call, "Call") { dial?.dial(e.number) }
                    QuickAction(Icons.Default.Message, "Message") { sendSms(context, e.number) }
                    if (item.isUnknown) {
                        QuickAction(Icons.Default.PersonAdd, "Save") { onSaveContact(e.number) }
                    } else {
                        item.contact?.let { ct -> QuickAction(Icons.Default.Person, "Contact") { onOpenContact(ct.id) } }
                    }
                    QuickAction(Icons.Default.Block, if (isBlocked) "Unblock" else "Block") {
                        if (isBlocked) vm.unblock(e.number) else vm.block(e.number)
                    }
                }
            }

            SectionLabel("This call", Modifier.padding(top = 16.dp))
            DetailRow("Type", kindLabel(e.kind))
            DetailRow("When", TimeUtils.dateTime(context, e.dateMillis))
            if (e.kind != CallKind.Missed && e.kind != CallKind.Rejected) DetailRow("Duration", TimeUtils.spoken(e.durationSec))
            e.simLabel?.let { DetailRow("SIM", it) }

            SectionLabel("Private note", Modifier.padding(top = 8.dp))
            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it },
                placeholder = { Text("Only stored on this phone") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.End) {
                Button(onClick = { vm.saveNote(e, noteText) }, enabled = noteText.trim() != savedNote) {
                    Text(if (noteText.isBlank() && savedNote.isNotEmpty()) "Remove note" else "Save note")
                }
            }

            if (history.isNotEmpty()) {
                SectionLabel("Other calls with this number")
                history.forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpenCall(h.entry.id) }.padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            kindIcon(h.entry.kind), contentDescription = kindLabel(h.entry.kind),
                            tint = if (h.entry.kind == CallKind.Missed) PulseColors.EndRed else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.size(12.dp))
                        Text(TimeUtils.dateTime(context, h.entry.dateMillis), modifier = Modifier.weight(1f))
                        if (h.entry.durationSec > 0) {
                            Text(TimeUtils.spoken(h.entry.durationSec), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            TextButton(
                onClick = { confirmDelete = true },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("  Delete this entry", color = MaterialTheme.colorScheme.error)
            }
        }

        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Delete this call entry?") },
                text = { Text("It is removed from your phone's call log, together with its note.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmDelete = false
                        vm.deleteEntry(e) { ok ->
                            if (ok) onBack()
                            else android.widget.Toast.makeText(context, "Android did not allow deleting this entry", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Delete") }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value)
    }
}
