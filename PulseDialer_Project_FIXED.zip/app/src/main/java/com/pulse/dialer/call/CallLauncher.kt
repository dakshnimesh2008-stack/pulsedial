package com.pulse.dialer.call

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccount
import android.telecom.TelecomManager
import com.pulse.dialer.data.model.SimInfo
import com.pulse.dialer.util.PhoneUtils

/** Places real cellular calls through Android Telecom. Returns false if Android refuses (e.g. no permission). */
object CallLauncher {
    fun place(context: Context, number: String, sim: SimInfo?): Boolean {
        val tm = context.getSystemService(TelecomManager::class.java) ?: return false
        val clean = PhoneUtils.strip(number)
        if (clean.isBlank()) return false
        val uri = Uri.fromParts(PhoneAccount.SCHEME_TEL, clean, null)
        val extras = Bundle()
        sim?.handle?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
        return try {
            tm.placeCall(uri, extras)
            true
        } catch (e: SecurityException) {
            false
        } catch (e: Exception) {
            false
        }
    }
}
